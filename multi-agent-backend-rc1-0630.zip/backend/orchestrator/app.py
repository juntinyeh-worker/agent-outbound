"""FastAPI app with WebSocket, Bedrock Claude intent parsing, and AgentCore Runtime invocation."""
import asyncio
import json
import uuid
import os
import time
import logging
from datetime import datetime

import boto3
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from orchestrator.services.intent_service import parse_intent
from orchestrator.services.task_dispatcher import TaskDispatcher
from orchestrator.services.pipeline_service import PipelineService, list_all_tasks

_dispatcher = TaskDispatcher()
_pipeline = PipelineService(_dispatcher)

logger = logging.getLogger(__name__)

sessions: dict[str, dict] = {}

TASK_TABLE = os.getenv("TASK_TABLE", "")
TASK_TTL_HOURS = int(os.getenv("TASK_TTL_HOURS", "48"))
_ddb = boto3.resource("dynamodb").Table(TASK_TABLE) if TASK_TABLE else None


def _save_task(session_id: str, task: dict):
    """Persist task to DynamoDB with TTL."""
    if not _ddb:
        return
    try:
        ttl = int(time.time()) + TASK_TTL_HOURS * 3600
        _ddb.put_item(Item={
            "sessionId": session_id,
            "taskId": task["id"],
            "status": task.get("status", "running"),
            "brief": task.get("brief", ""),
            "result": json.dumps(task.get("result", ""), default=str)[:400000],
            "started": task.get("started", ""),
            "completed": task.get("completed", ""),
            "name": task.get("tool", ""),
            "ttl": ttl,
        })
    except Exception as e:
        logger.warning(f"Failed to save task to DynamoDB: {e}")


def _save_handoff(session_id: str, handoff: dict, sequence: int):
    """Persist handoff artifact to DynamoDB (same table, SK=handoff#N)."""
    if not _ddb:
        return
    try:
        ttl = int(time.time()) + TASK_TTL_HOURS * 3600
        _ddb.put_item(Item={
            "sessionId": session_id,
            "taskId": f"handoff#{sequence:04d}",
            "from_role": handoff.get("from_role", ""),
            "summary": handoff.get("summary", "")[:1000],
            "artifact": handoff.get("artifact", "")[:390000],
            "timestamp": datetime.utcnow().isoformat(),
            "ttl": ttl,
        })
    except Exception as e:
        logger.warning(f"Failed to save handoff to DynamoDB: {e}")


def _load_last_handoff(session_id: str) -> dict | None:
    """Load the most recent handoff artifact for a session from DynamoDB."""
    if not _ddb:
        return None
    try:
        from boto3.dynamodb.conditions import Key
        resp = _ddb.query(
            KeyConditionExpression=Key("sessionId").eq(session_id) & Key("taskId").begins_with("handoff#"),
            ScanIndexForward=False,
            Limit=1,
        )
        items = resp.get("Items", [])
        if items:
            item = items[0]
            return {
                "from_role": item.get("from_role", ""),
                "summary": item.get("summary", ""),
                "artifact": item.get("artifact", ""),
            }
        return None
    except Exception as e:
        logger.warning(f"Failed to load handoff from DynamoDB: {e}")
        return None


def _get_handoff_count(session_id: str) -> int:
    """Get the number of handoffs in a session (for sequence numbering)."""
    if not _ddb:
        return 0
    try:
        from boto3.dynamodb.conditions import Key
        resp = _ddb.query(
            KeyConditionExpression=Key("sessionId").eq(session_id) & Key("taskId").begins_with("handoff#"),
            Select="COUNT",
        )
        return resp.get("Count", 0)
    except Exception:
        return 0


def _get_task(session_id: str, task_id: str) -> dict | None:
    """Fetch task from DynamoDB."""
    if not _ddb:
        return None
    try:
        resp = _ddb.get_item(Key={"sessionId": session_id, "taskId": task_id})
        item = resp.get("Item")
        if item:
            result = item.get("result", "")
            try:
                result = json.loads(result)
            except (json.JSONDecodeError, TypeError):
                pass
            return {"status": item["status"], "task_id": item["taskId"], "brief": item.get("brief", ""), "result": result}
        return None
    except Exception as e:
        logger.warning(f"Failed to get task from DynamoDB: {e}")
        return None


def create_orchestrator_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(title="AgentCore Long-Running Orchestrator", version="0.1.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health():
        return {"status": "healthy", "mode": "agentcore-longrun", "timestamp": datetime.utcnow().isoformat()}

    @app.get("/")
    @app.get("/api/orchestrator")
    async def root():
        return {"service": "agentcore-longrun-orchestrator", "version": "0.2.0"}

    @app.get("/api/orchestrator/tasks/{session_id}/{task_id}")
    async def get_task_result(session_id: str, task_id: str):
        """Check a specific task result via HTTP. Works after WS disconnect."""
        # Check in-memory first
        if session_id in sessions:
            task = next((t for t in sessions[session_id]["tasks"] if t["id"] == task_id), None)
            if task:
                return {"status": task["status"], "task_id": task_id, "brief": task.get("brief", ""), "result": task.get("result")}
        # Check DynamoDB
        item = _get_task(session_id, task_id)
        if item:
            return item
        return {"status": "unknown", "error": "Task not found"}

    @app.get("/api/orchestrator/task/{task_id}")
    async def get_task_by_id(task_id: str):
        """Check task result by taskId only. Scans all sessions."""
        # Check in-memory
        for sid, sess in sessions.items():
            task = next((t for t in sess["tasks"] if t["id"] == task_id), None)
            if task:
                return {"status": task["status"], "task_id": task_id, "brief": task.get("brief", ""), "result": task.get("result")}
        # Scan DynamoDB by taskId (GSI not needed for low volume)
        if not _ddb:
            return {"status": "unknown", "error": "No task store configured"}
        try:
            from boto3.dynamodb.conditions import Attr
            resp = _ddb.scan(FilterExpression=Attr("taskId").eq(task_id), Limit=10)
            items = resp.get("Items", [])
            if items:
                item = items[0]
                result = item.get("result", "")
                try:
                    result = json.loads(result)
                except (json.JSONDecodeError, TypeError):
                    pass
                return {"status": item["status"], "task_id": task_id, "brief": item.get("brief", ""), "result": result}
            return {"status": "unknown", "error": "Task not found"}
        except Exception as e:
            return {"status": "unknown", "error": str(e)[:200]}

    @app.get("/api/tasks")
    async def get_all_tasks():
        """List all recent tasks and pipelines globally (demo mode, no session filter)."""
        return {"tasks": list_all_tasks()}

    @app.get("/api/tasks/{run_id}")
    async def get_pipeline_detail(run_id: str):
        """Get detailed pipeline status with all stages."""
        return await _pipeline.get_pipeline_status(run_id)

    @app.get("/api/tasks/{run_id}/artifacts")
    async def list_pipeline_artifacts(run_id: str):
        """List all artifact files for a pipeline run."""
        task_log_bucket = os.getenv("TASK_LOG_BUCKET", "")
        if not task_log_bucket:
            return {"artifacts": [], "error": "TASK_LOG_BUCKET not configured"}
        try:
            s3 = boto3.client("s3")
            prefix = f"pipelines/{run_id}/"
            resp = s3.list_objects_v2(Bucket=task_log_bucket, Prefix=prefix)
            artifacts = []
            for obj in resp.get("Contents", []):
                key = obj["Key"]
                filename = key[len(prefix):]
                if filename:
                    artifacts.append({
                        "filename": filename,
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                        "url": f"/api/tasks/{run_id}/artifacts/{filename}",
                    })
            return {"run_id": run_id, "artifacts": artifacts}
        except Exception as e:
            return {"artifacts": [], "error": str(e)[:200]}

    @app.get("/api/tasks/{run_id}/artifacts/{filename:path}")
    async def get_pipeline_artifact(run_id: str, filename: str):
        """Download a specific artifact file content."""
        from fastapi.responses import Response
        task_log_bucket = os.getenv("TASK_LOG_BUCKET", "")
        if not task_log_bucket:
            return {"error": "TASK_LOG_BUCKET not configured"}
        # Validate filename to prevent path traversal
        if ".." in filename or filename.startswith("/"):
            return {"error": "Invalid filename"}
        try:
            s3 = boto3.client("s3")
            key = f"pipelines/{run_id}/{filename}"
            obj = s3.get_object(Bucket=task_log_bucket, Key=key)
            content = obj["Body"].read().decode("utf-8")
            return Response(content=content, media_type="text/markdown; charset=utf-8",
                          headers={"Content-Disposition": f"inline; filename={filename}"})
        except Exception as e:
            return {"error": f"Artifact not found: {str(e)[:200]}"}

    @app.post("/api/tasks/{run_id}/retry")
    async def retry_pipeline(run_id: str):
        """Rerun a stalled/failed pipeline from scratch."""
        try:
            # Get original user_input from DDB
            status = await _pipeline.get_pipeline_status(run_id)
            user_input = status.get("user_input", "")
            if not user_input:
                return {"status": "error", "error": "Pipeline not found or no user_input stored"}

            # Clean up old stage entries in DDB
            if _ddb:
                for stage_num in range(1, 7):
                    try:
                        _ddb.delete_item(Key={"sessionId": f"pipeline#{run_id}", "taskId": f"stage#{stage_num:02d}"})
                    except Exception:
                        pass
                # Reset meta
                _ddb.put_item(Item={
                    "sessionId": f"pipeline#{run_id}",
                    "taskId": "meta",
                    "status": "running",
                    "current_stage": 0,
                    "total": 6,
                    "user_input": user_input[:5000],
                    "started_at": datetime.utcnow().isoformat(),
                    "ttl": int(time.time()) + 48 * 3600,
                })

            # Re-fire the supervisor
            project_id = os.getenv("PROJECT_ID", "plx-msp-checker")
            await _pipeline.start_pipeline(run_id, user_input, project_id)
            return {"status": "started", "run_id": run_id}
        except Exception as e:
            return {"status": "error", "error": str(e)[:200]}

    @app.websocket("/ws")
    @app.websocket("/api/orchestrator/ws")
    async def websocket_endpoint(ws: WebSocket):
        await ws.accept()
        session_id = str(uuid.uuid4())[:8]
        session = {"id": session_id, "created": datetime.utcnow().isoformat(), "tasks": [], "history": [], "last_artifact": None}
        sessions[session_id] = session
        await ws.send_json({"type": "session", "session_id": session_id})

        try:
            while True:
                data = await ws.receive_text()
                msg = json.loads(data)

                # Handle session resume request
                if msg.get("type") == "resume":
                    requested_id = msg.get("session_id", "")
                    if requested_id and requested_id in sessions:
                        # Reuse existing session
                        session_id = requested_id
                        session = sessions[session_id]
                        await ws.send_json({"type": "session", "session_id": session_id, "resumed": True})
                    else:
                        # Session expired or not found — keep the new one
                        await ws.send_json({"type": "session", "session_id": session_id, "resumed": False})
                    continue

                user_text = msg.get("text", "")
                client_role_id = msg.get("role_id", "")  # Client can force a role
                use_handoff = msg.get("handoff", False)   # Client signals: use previous output as input
                session["history"].append({"role": "user", "text": user_text})

                pending_done = [t for t in session["tasks"] if t["status"] == "done" and not t.get("delivered")]
                intent = await parse_intent(user_text, pending_done)

                if intent.get("follow_up"):
                    if pending_done:
                        task = pending_done[0]
                        task["delivered"] = True
                        if intent["follow_up"] == "detail":
                            await ws.send_json({"type": "detail", "task_id": task["id"], "message": "Here's the full detail:", "data": task["result"]})
                        else:
                            await ws.send_json({"type": "brief", "task_id": task["id"], "message": task["brief"]})
                    continue

                tools_to_run = intent.get("tools", [])
                ack = intent.get("ack", "")
                # Role selection: client override > intent router > default
                role_id = client_role_id or intent.get("role_id", "")

                # PIPELINE MODE: fire supervisor agent async, poll DDB for progress
                if intent.get("pipeline"):
                    pipeline_input = intent.get("input", user_text)
                    await ws.send_json({"type": "pipeline_start", "message": ack or "🚀 Starting multi-role pipeline..."})
                    project_id = os.getenv("PROJECT_ID", "plx-msp-checker")
                    run_id = str(uuid.uuid4())[:8]
                    await ws.send_json({"type": "pipeline_meta", "run_id": run_id, "total": 6})

                    # Fire and forget — supervisor handles orchestration internally
                    asyncio.create_task(_fire_pipeline(run_id, pipeline_input, project_id, ws))
                    continue

                # Build input_context from previous handoff artifact
                input_context = None
                if use_handoff:
                    # Try in-memory first, fall back to DynamoDB
                    input_context = session.get("last_artifact") or _load_last_handoff(session_id)

                if tools_to_run:
                    await ws.send_json({"type": "ack", "message": ack, "role": role_id})
                    user_input = intent.get("input", user_text)
                    for tool_name in tools_to_run:
                        task_id = str(uuid.uuid4())[:8]
                        task = {"id": task_id, "tool": tool_name, "role": role_id, "status": "running", "started": datetime.utcnow().isoformat()}
                        session["tasks"].append(task)
                        _save_task(session_id, task)
                        await ws.send_json({"type": "task_started", "task_id": task_id, "role": role_id})
                        asyncio.create_task(_run_task(task_id, user_input, role_id, input_context, ws, session))
                elif ack:
                    await ws.send_json({"type": "chat", "message": ack, "role": role_id})

        except WebSocketDisconnect:
            sessions.pop(session_id, None)

    return app


async def _run_task(task_id: str, user_input: str, role_id: str, input_context: dict, ws: WebSocket, session: dict):
    """Execute AgentCore runtime invocation with role context and handoff support."""
    task = next(t for t in session["tasks"] if t["id"] == task_id)
    session_id = session["id"]
    project_id = os.getenv("PROJECT_ID", "plx-msp-checker")

    ping_active = True

    async def _ping_loop():
        while ping_active:
            await asyncio.sleep(15)
            if not ping_active:
                break
            try:
                await ws.send_json({"type": "ping", "task_id": task_id})
            except Exception:
                break

    ping_task = asyncio.create_task(_ping_loop())

    try:
        result = await _dispatcher.dispatch(role_id, user_input, project_id, input_context)
        brief = result.get("response", str(result))
        task["status"] = "done"
        task["result"] = result
        task["brief"] = brief
        task["completed"] = datetime.utcnow().isoformat()

        # Store output_artifact for handoff to next role
        output_artifact = result.get("output_artifact")
        if output_artifact:
            handoff_data = {
                "from_role": role_id,
                "artifact": output_artifact.get("content", brief),
                "summary": output_artifact.get("summary", brief[:200])
            }
            session["last_artifact"] = handoff_data
            task["output_artifact"] = output_artifact
            # Persist to DynamoDB
            seq = _get_handoff_count(session_id)
            _save_handoff(session_id, handoff_data, seq)

        _save_task(session_id, task)
        try:
            msg = {"type": "task_complete", "task_id": task_id, "brief": brief, "role": role_id}
            if output_artifact:
                msg["has_artifact"] = True
                msg["artifact_summary"] = output_artifact.get("summary", "")
            await ws.send_json(msg)
        except Exception:
            logger.info(f"Task {task_id} completed but WS closed. Result saved to DynamoDB.")
    except Exception as e:
        if task["status"] != "done":
            task["status"] = "error"
            task["error"] = str(e)[:200]
            task["completed"] = datetime.utcnow().isoformat()
            _save_task(session_id, task)
        try:
            await ws.send_json({"type": "task_error", "task_id": task_id, "message": f"Error: {str(e)[:200]}"})
        except Exception:
            pass
    finally:
        ping_active = False
        ping_task.cancel()


async def _fire_pipeline(run_id: str, user_input: str, project_id: str, ws: WebSocket):
    """Fire supervisor agent and poll DynamoDB for status updates."""
    try:
        # Start the supervisor (fires async — supervisor writes to DDB as it progresses)
        await _pipeline.start_pipeline(run_id, user_input, project_id)
    except Exception as e:
        logger.error(f"Failed to start pipeline {run_id}: {e}")
        try:
            await ws.send_json({"type": "pipeline_complete", "run_id": run_id, "status": "error", "stages_completed": 0, "total": 6})
        except Exception:
            pass
        return

    # Poll DDB for progress every 5s
    last_stage_seen = 0
    stall_count = 0
    try:
        for _ in range(360):  # Max 30 minutes (360 * 5s)
            await asyncio.sleep(5)
            status = await _pipeline.get_pipeline_status(run_id)

            # Push new stage updates
            for stage_info in status.get("stages", []):
                stage_num = stage_info["stage"]
                if stage_num > last_stage_seen or (stage_num == last_stage_seen and stage_info["status"] == "done"):
                    try:
                        await ws.send_json({
                            "type": "pipeline_stage",
                            "run_id": run_id,
                            "stage": stage_num,
                            "total": status.get("total", 6),
                            "role": stage_info.get("role_id", ""),
                            "name": stage_info.get("role_name", ""),
                            "status": stage_info["status"],
                            "brief": stage_info.get("summary", "")[:500],
                        })
                    except Exception:
                        return
                    if stage_info["status"] == "done":
                        last_stage_seen = stage_num
                        stall_count = 0

            # Check completion
            if status.get("status") in ("complete", "error"):
                try:
                    await ws.send_json({
                        "type": "pipeline_complete",
                        "run_id": run_id,
                        "status": status["status"],
                        "stages_completed": len([s for s in status.get("stages", []) if s["status"] == "done"]),
                        "total": status.get("total", 6),
                    })
                except Exception:
                    pass
                return

            # Stall detection
            stall_count += 1
            if stall_count > 180:  # 15 min with no progress
                try:
                    await ws.send_json({"type": "pipeline_complete", "run_id": run_id, "status": "stalled", "stages_completed": last_stage_seen, "total": 6})
                except Exception:
                    pass
                return
    except Exception as e:
        logger.error(f"Pipeline poll error: {e}")
