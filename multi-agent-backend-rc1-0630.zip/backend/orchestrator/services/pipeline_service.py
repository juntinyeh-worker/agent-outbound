"""Pipeline service — fires supervisor agent async and polls DynamoDB for status."""
import os
import json
import time
import logging
from datetime import datetime
import boto3
from boto3.dynamodb.conditions import Key

logger = logging.getLogger(__name__)

TASK_TABLE = os.getenv("TASK_TABLE", "")
REGION = os.getenv("AWS_REGION", "us-west-2")

_ddb = boto3.resource("dynamodb", region_name=REGION).Table(TASK_TABLE) if TASK_TABLE else None


class PipelineService:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher

    async def start_pipeline(self, run_id: str, user_input: str, project_id: str):
        """Fire the supervisor agent (async) and return immediately.
        
        The supervisor agent will manage the pipeline stages internally
        and write status to DynamoDB as it progresses.
        """
        import asyncio
        
        # 1. Write initial pipeline state to DynamoDB
        if _ddb:
            ttl = int(time.time()) + 48 * 3600
            _ddb.put_item(Item={
                "sessionId": f"pipeline#{run_id}",
                "taskId": "meta",
                "status": "running",
                "current_stage": 0,
                "total": 6,
                "user_input": user_input[:5000],
                "started_at": datetime.utcnow().isoformat(),
                "ttl": ttl,
            })

        # 2. Fire supervisor in background — do NOT await the result
        supervisor_input = f"Pipeline Run ID: {run_id}\n\nUser Request: {user_input}"
        
        async def _background_dispatch():
            try:
                await self.dispatcher.dispatch(
                    role_id="supervisor",
                    user_input=supervisor_input,
                    project_id=project_id,
                )
            except Exception as e:
                logging.getLogger(__name__).error(f"Supervisor dispatch failed: {e}")

        asyncio.create_task(_background_dispatch())

    async def get_pipeline_status(self, run_id: str) -> dict:
        """Poll DynamoDB for current pipeline state."""
        if not _ddb:
            return {"status": "unknown", "stages": []}

        try:
            resp = _ddb.query(
                KeyConditionExpression=Key("sessionId").eq(f"pipeline#{run_id}"),
            )
            items = resp.get("Items", [])
            if not items:
                return {"status": "unknown", "stages": []}

            meta = next((i for i in items if i["taskId"] == "meta"), {})
            stages = sorted(
                [i for i in items if i["taskId"].startswith("stage#")],
                key=lambda x: x["taskId"]
            )

            return {
                "run_id": run_id,
                "status": meta.get("status", "unknown"),
                "current_stage": int(meta.get("current_stage", 0)),
                "total": int(meta.get("total", 6)),
                "user_input": meta.get("user_input", ""),
                "started_at": meta.get("started_at", ""),
                "stages": [
                    {
                        "stage": int(s["taskId"].replace("stage#", "")),
                        "role_id": s.get("role_id", ""),
                        "role_name": s.get("role_name", ""),
                        "status": s.get("status", ""),
                        "summary": s.get("summary", ""),
                        "started_at": s.get("started_at", ""),
                        "completed_at": s.get("completed_at", ""),
                    }
                    for s in stages
                ],
            }
        except Exception as e:
            logger.error(f"Failed to get pipeline status: {e}")
            return {"status": "error", "stages": []}


def list_all_tasks() -> list[dict]:
    """List all recent tasks/pipelines from DynamoDB (global, no session filter)."""
    if not _ddb:
        return []

    try:
        # Scan for pipeline metas and recent tasks (limited to 50 items for demo)
        resp = _ddb.scan(
            FilterExpression="taskId = :meta OR (attribute_exists(#s) AND taskId <> :meta)",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":meta": "meta"},
            Limit=100,
        )
        items = resp.get("Items", [])

        # Group by pipeline and standalone tasks
        pipelines = {}
        tasks = []

        for item in items:
            session_id = item.get("sessionId", "")
            task_id = item.get("taskId", "")

            if session_id.startswith("pipeline#"):
                run_id = session_id.replace("pipeline#", "")
                if run_id not in pipelines:
                    pipelines[run_id] = {"type": "pipeline", "run_id": run_id, "stages": []}
                if task_id == "meta":
                    pipelines[run_id].update({
                        "status": item.get("status", ""),
                        "current_stage": int(item.get("current_stage", 0)),
                        "total": int(item.get("total", 6)),
                        "user_input": item.get("user_input", "")[:200],
                        "started_at": item.get("started_at", ""),
                    })
                elif task_id.startswith("stage#"):
                    pipelines[run_id]["stages"].append({
                        "stage": int(task_id.replace("stage#", "")),
                        "role_id": item.get("role_id", ""),
                        "role_name": item.get("role_name", ""),
                        "status": item.get("status", ""),
                        "summary": item.get("summary", "")[:300],
                    })
            elif not session_id.startswith("pipeline#") and task_id not in ("meta",) and not task_id.startswith("handoff#"):
                tasks.append({
                    "type": "task",
                    "task_id": task_id,
                    "session_id": session_id,
                    "status": item.get("status", ""),
                    "name": item.get("name", ""),
                    "brief": item.get("brief", "")[:200],
                    "started": item.get("started", ""),
                    "completed": item.get("completed", ""),
                })

        # Sort stages within each pipeline
        for p in pipelines.values():
            p["stages"].sort(key=lambda x: x["stage"])

        result = list(pipelines.values()) + tasks
        result.sort(key=lambda x: x.get("started_at", x.get("started", "")), reverse=True)
        return result[:50]
    except Exception as e:
        logger.error(f"Failed to list tasks: {e}")
        return []
