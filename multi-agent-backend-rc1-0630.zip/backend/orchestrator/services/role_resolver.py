"""Role resolver - loads role configs from S3."""
import json
import os
import time
import logging
from dataclasses import dataclass, field
import boto3

logger = logging.getLogger(__name__)

ROLE_STORE_BUCKET = os.getenv("ROLE_STORE_BUCKET", "")


@dataclass
class RoleConfig:
    steering: str = ""
    tools: list[str] = field(default_factory=list)
    model_id: str = ""


class RoleResolver:
    def __init__(self):
        self._s3 = boto3.client("s3") if ROLE_STORE_BUCKET else None
        self._cache: dict[str, tuple[list, float]] = {}

    def _get_index(self, project_id: str) -> list[dict]:
        """Load _index.json (list of role dicts) with 60s cache."""
        now = time.time()
        cached = self._cache.get(project_id)
        if cached and (now - cached[1]) < 60:
            return cached[0]
        if not self._s3:
            return []
        try:
            obj = self._s3.get_object(Bucket=ROLE_STORE_BUCKET, Key=f"{project_id}/_index.json")
            data = json.loads(obj["Body"].read())
            # Support both list format and {"roles": [...]} format
            roles = data if isinstance(data, list) else data.get("roles", [])
            self._cache[project_id] = (roles, now)
            return roles
        except Exception as e:
            logger.error(f"Failed to load {project_id}/_index.json: {e}")
            return []

    def resolve(self, project_id: str, role_id: str) -> RoleConfig:
        roles = self._get_index(project_id)
        role_meta = next((r for r in roles if r.get("role_id") == role_id), {})
        steering = ""
        if self._s3:
            try:
                obj = self._s3.get_object(Bucket=ROLE_STORE_BUCKET, Key=f"{project_id}/{role_id}.md")
                steering = obj["Body"].read().decode()
            except Exception:
                # Try _global fallback
                try:
                    obj = self._s3.get_object(Bucket=ROLE_STORE_BUCKET, Key=f"_global/{role_id}.md")
                    steering = obj["Body"].read().decode()
                except Exception as e:
                    logger.warning(f"No .md for role {role_id}: {e}")
        return RoleConfig(
            steering=steering,
            tools=role_meta.get("tools", []),
            model_id=role_meta.get("model_id", ""),
        )

    def get_routing_context(self, project_id: str) -> str:
        roles = self._get_index(project_id)
        if not roles:
            return ""
        lines = [f"- {r['role_id']}: {r.get('description', r['role_id'])}" for r in roles]
        return "\n".join(lines)

    def first_role_id(self, project_id: str) -> str:
        roles = self._get_index(project_id)
        return roles[0]["role_id"] if roles else "default"
