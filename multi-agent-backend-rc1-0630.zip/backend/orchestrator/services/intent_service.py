"""Intent parsing service using Bedrock Claude with role selection."""
import json
import os
import logging
import boto3

from .role_resolver import RoleResolver

logger = logging.getLogger(__name__)

BEDROCK_REGION = os.getenv("BEDROCK_REGION", "us-west-2")
MODEL_ID = os.getenv("MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0")
PROJECT_ID = os.getenv("PROJECT_ID", "plx-msp-checker")
DEMO_READ_ONLY = os.getenv("DEMO_READ_ONLY", "false").lower() == "true"

_role_resolver = RoleResolver()

_SYSTEM_PROMPT_FULL = """You are the intent router for a Cloud Operations Assistant powered by Amazon Bedrock via AgentCore Runtime.
This platform helps with AWS cloud operations: building code, running cloud commands, live event handling, incident response, and account management.

Classify each user message into one of four tiers and respond ONLY with JSON:

TIER 1 — DECLINE (non-AWS/non-cloud topics):
If the request is unrelated to AWS, cloud operations, coding, or DevOps (e.g. recipes, sports, personal advice), politely decline:
{{"tools": [], "ack": "I'm a Cloud Operations Assistant focused on AWS. I can help with cloud infrastructure, coding, incident response, and account operations. How can I help with your AWS needs?"}}

TIER 2 — ANSWER DIRECTLY (AWS knowledge, no account access needed):
If the request is about general AWS knowledge, best practices, service explanations, or architecture guidance that requires no account data or actions:
{{"tools": [], "ack": "your helpful response here"}}

TIER 3 — ROUTE TO AGENT (account actions, code generation, live operations):
If the request involves any of these, forward to the agent and select the best role:
- Building or reviewing code/templates (CFN, CDK, Terraform, scripts)
- Querying account state (resources, costs, security findings, logs)
- Cloud operations (deployments, scaling, troubleshooting)
- Incident response or live event handling
- Any task that benefits from tool access or code execution

Available specialist roles:
{roles}

Pick the most appropriate role_id from the list above.
{{"tier": 3, "role_id": "<best role_id>", "ack": "brief acknowledgment", "input": "the user's original request"}}

TIER 4 — PIPELINE (multi-stage delivery workflow):
If the user describes a project, feature, or product they want built END-TO-END — involving requirements, design, implementation, testing, deployment — trigger the pipeline.
Indicators: user says "I want to build...", "I am a PM...", "I need a feature...", "deliver a...", "create a full...", describes multiple stages of work, mentions roles like PM/architect/developer.
{{"tier": 4, "pipeline": true, "ack": "Starting multi-role pipeline for your request...", "input": "the user's feature/project description"}}

FOLLOW-UP on previous results (e.g. "yes", "detail", "brief"):
{{"tools": [], "ack": "", "follow_up": "brief|detail"}}

IMPORTANT: Never expose confidential account data (credentials, keys, tokens) in responses. When in doubt between Tier 3 and Tier 4, prefer Tier 3 unless the user clearly wants end-to-end delivery."""

_SYSTEM_PROMPT_READONLY = """You are the intent router for a Cloud Operations Assistant powered by Amazon Bedrock via AgentCore Runtime.
This is a PUBLIC DEMO environment. The agent operates in READ-ONLY mode.

Classify each user message into one of three tiers and respond ONLY with JSON:

TIER 1 — DECLINE (non-AWS/non-cloud topics OR write/mutating operations):
Decline if the request is unrelated to AWS, OR if it requests any write/mutating action such as:
create, delete, update, modify, terminate, stop, start, launch, deploy, put, attach, detach, reboot, scale, tag, untag, enable, disable, revoke, authorize, or any action that changes state.
{{"tools": [], "ack": "This is a read-only demo environment. I can help you inspect and query AWS resources, but I cannot perform actions that modify infrastructure. Try asking me to list, describe, or check the status of your resources!"}}

TIER 2 — ANSWER DIRECTLY (AWS knowledge, no account access needed):
If the request is about general AWS knowledge, best practices, service explanations, or architecture guidance:
{{"tools": [], "ack": "your helpful response here"}}

TIER 3 — ROUTE TO AGENT (read-only queries that need account access):
Only forward requests that are strictly read-only. Select the best specialist role.

Available specialist roles:
{roles}

Pick the most appropriate role_id from the list above.
Prepend "READ-ONLY MODE: Only use describe, list, get, and read operations. Do NOT run any command that creates, modifies, or deletes resources." to the input.
{{"tier": 3, "role_id": "<best role_id>", "ack": "brief acknowledgment", "input": "READ-ONLY MODE: Only use describe, list, get, and read operations. Do NOT run any command that creates, modifies, or deletes resources. <user request here>"}}

FOLLOW-UP on previous results (e.g. "yes", "detail", "brief"):
{{"tools": [], "ack": "", "follow_up": "brief|detail"}}

IMPORTANT: Never expose confidential account data (credentials, keys, tokens) in responses. When in doubt between allowing and blocking, BLOCK the request."""


def _build_system_prompt() -> str:
    roles_ctx = _role_resolver.get_routing_context(PROJECT_ID) or "- default: general cloud operations"
    template = _SYSTEM_PROMPT_READONLY if DEMO_READ_ONLY else _SYSTEM_PROMPT_FULL
    return template.format(roles=roles_ctx)


def _get_client():
    return boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)


def _default_role_id() -> str:
    return _role_resolver.first_role_id(PROJECT_ID)


async def parse_intent(message: str, pending_tasks: list[dict]) -> dict:
    """Use Claude to parse user intent with role selection."""
    client = _get_client()
    system = _build_system_prompt()
    if pending_tasks:
        system += f"\nPending results: {json.dumps([{'id': t['id'], 'tool': t['tool']} for t in pending_tasks])}"

    resp = client.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "system": system,
            "messages": [{"role": "user", "content": message}],
        }),
    )
    body = json.loads(resp["body"].read())
    text = body["content"][0]["text"]
    try:
        if "```" in text:
            text = text.split("```")[1].strip()
            if text.startswith("json"):
                text = text[4:]
        result = json.loads(text.strip())
    except Exception:
        return {"tools": [], "ack": text}

    # Backward compat: normalize tier-3 responses
    if result.get("tier") == 3 or "input" in result:
        if "role_id" not in result:
            result["role_id"] = _default_role_id()
        result.setdefault("tier", 3)
        # Keep tools key for backward compat
        result.setdefault("tools", ["ask_agent"])
    return result
