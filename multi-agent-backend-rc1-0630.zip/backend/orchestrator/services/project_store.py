"""Project config loader from S3."""
import json
import os
import time
import logging
import boto3

logger = logging.getLogger(__name__)

ROLE_STORE_BUCKET = os.getenv("ROLE_STORE_BUCKET", "")


class ProjectStore:
    def __init__(self):
        self._s3 = boto3.client("s3")
        self._cache: dict[str, tuple[dict, float]] = {}

    def get_project(self, project_id: str) -> dict:
        now = time.time()
        cached = self._cache.get(project_id)
        if cached and (now - cached[1]) < 60:
            return cached[0]
        try:
            obj = self._s3.get_object(Bucket=ROLE_STORE_BUCKET, Key=f"{project_id}/project.json")
            data = json.loads(obj["Body"].read())
            self._cache[project_id] = (data, now)
            return data
        except Exception as e:
            logger.error(f"Failed to load project {project_id}: {e}")
            return {}

    def list_projects(self) -> list[str]:
        try:
            resp = self._s3.list_objects_v2(Bucket=ROLE_STORE_BUCKET, Delimiter="/")
            return [p["Prefix"].rstrip("/") for p in resp.get("CommonPrefixes", [])]
        except Exception as e:
            logger.error(f"Failed to list projects: {e}")
            return []
