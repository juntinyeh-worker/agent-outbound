#!/usr/bin/env bash
# deploy.sh — Rebuild and deploy multi-agent-backend (idempotent, CFN-safe)
set -euo pipefail

REGION="${AWS_REGION:-us-west-2}"
STACK="sandbox-plx-msp-checker"
BUCKET="sandbox-plx-msp-source-256358067059"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════════"
echo " Multi-Agent Backend — Deploy"
echo " Stack: $STACK | Region: $REGION"
echo "═══════════════════════════════════════════════════════"

# ============ 1. Package source zips ============
echo "==> [1/5] Packaging source..."
cd "$SRC"
zip -qr /tmp/backend-source.zip backend/ -x '*__pycache__*' '*.pyc'
zip -qr /tmp/agent-source.zip agent/ -x '*__pycache__*' '*.pyc'
zip -qr /tmp/frontend-source.zip frontend/
zip -qr /tmp/roles-source.zip roles/ -x 'roles/sync-to-s3.sh'
echo "    Done."

# ============ 2. Upload to S3 ============
echo "==> [2/5] Uploading sources to s3://$BUCKET/..."
aws s3 cp /tmp/backend-source.zip "s3://$BUCKET/backend-source.zip" --region "$REGION" --quiet
aws s3 cp /tmp/agent-source.zip "s3://$BUCKET/agent-source.zip" --region "$REGION" --quiet
aws s3 cp /tmp/frontend-source.zip "s3://$BUCKET/frontend-source.zip" --region "$REGION" --quiet
aws s3 cp /tmp/roles-source.zip "s3://$BUCKET/roles-source.zip" --region "$REGION" --quiet
echo "    Done."

# ============ 3. Update CFN stack (source of truth) ============
echo "==> [3/5] Updating CloudFormation stack..."
aws cloudformation update-stack \
  --stack-name "$STACK" \
  --template-body "file://$SRC/cfn-template.yaml" \
  --parameters \
    ParameterKey=SourceBucket,ParameterValue="$BUCKET" \
    ParameterKey=Environment,ParameterValue=dev \
    ParameterKey=ModelId,ParameterValue="us.anthropic.claude-sonnet-4-6" \
    ParameterKey=AgentModelId,ParameterValue="us.anthropic.claude-sonnet-4-6" \
    ParameterKey=DemoMaskOutput,ParameterValue=false \
    ParameterKey=DemoReadOnly,ParameterValue=false \
  --capabilities CAPABILITY_IAM \
  --region "$REGION" 2>&1 || echo "    (No CFN changes needed — stack is current)"

# Wait for CFN update if it started
STATUS=$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query "Stacks[0].StackStatus" --output text)
if [[ "$STATUS" == *"IN_PROGRESS"* ]]; then
  echo "    Waiting for stack update..."
  aws cloudformation wait stack-update-complete --stack-name "$STACK" --region "$REGION" 2>/dev/null || true
  echo "    Stack update complete."
fi

# ============ 4. Trigger CodeBuild projects ============
echo "==> [4/5] Triggering builds..."
BE_ID=$(aws codebuild start-build --project-name "${STACK}-backend-build" --region "$REGION" --query "build.id" --output text)
AG_ID=$(aws codebuild start-build --project-name "${STACK}-agent-build" --region "$REGION" --query "build.id" --output text)
FE_ID=$(aws codebuild start-build --project-name "${STACK}-frontend-build" --region "$REGION" --query "build.id" --output text)
RS_ID=$(aws codebuild start-build --project-name "${STACK}-roles-sync" --region "$REGION" --query "build.id" --output text)
echo "    Backend: $BE_ID"
echo "    Agent:   $AG_ID"
echo "    Frontend: $FE_ID"
echo "    Roles:   $RS_ID"

# Wait for builds
echo "    Waiting for builds (up to 5 min)..."
for i in $(seq 1 60); do
  sleep 5
  BE_S=$(aws codebuild batch-get-builds --ids "$BE_ID" --region "$REGION" --query "builds[0].buildStatus" --output text)
  AG_S=$(aws codebuild batch-get-builds --ids "$AG_ID" --region "$REGION" --query "builds[0].buildStatus" --output text)
  FE_S=$(aws codebuild batch-get-builds --ids "$FE_ID" --region "$REGION" --query "builds[0].buildStatus" --output text)
  if [[ "$BE_S" != "IN_PROGRESS" && "$AG_S" != "IN_PROGRESS" && "$FE_S" != "IN_PROGRESS" ]]; then
    break
  fi
done
echo "    Backend: $BE_S | Agent: $AG_S | Frontend: $FE_S"

if [[ "$BE_S" != "SUCCEEDED" || "$AG_S" != "SUCCEEDED" || "$FE_S" != "SUCCEEDED" ]]; then
  echo "    ❌ One or more builds failed!"
  exit 1
fi

# ============ 5. Deploy services ============
echo "==> [5/5] Deploying..."

# ECS force new deployment
SERVICE_ARN=$(aws ecs list-services --cluster "${STACK}-cluster" --region "$REGION" --query "serviceArns[0]" --output text)
aws ecs update-service --cluster "${STACK}-cluster" --service "$SERVICE_ARN" --force-new-deployment --region "$REGION" --query "service.deployments[0].status" --output text

# AgentCore runtime — use CFN to manage (env vars are already set by CFN)
# Only update the image reference to trigger new version
RUNTIME_ID=$(aws cloudformation describe-stack-resources --stack-name "$STACK" --region "$REGION" --query "StackResources[?LogicalResourceId=='AgentCoreRuntime'].PhysicalResourceId" --output text)
ROLE_ARN=$(aws iam get-role --role-name "$(aws cloudformation describe-stack-resources --stack-name "$STACK" --region "$REGION" --query "StackResources[?LogicalResourceId=='AgentCoreRuntimeRole'].PhysicalResourceId" --output text)" --query "Role.Arn" --output text)

aws bedrock-agentcore-control update-agent-runtime \
  --agent-runtime-id "$RUNTIME_ID" \
  --role-arn "$ROLE_ARN" \
  --network-configuration '{"networkMode":"PUBLIC"}' \
  --agent-runtime-artifact "{\"containerConfiguration\":{\"containerUri\":\"$(aws sts get-caller-identity --query Account --output text).dkr.ecr.${REGION}.amazonaws.com/${STACK}-agent:latest\"}}" \
  --environment-variables "{\"ROLE_STORE_BUCKET\":\"${STACK}-roles-$(aws sts get-caller-identity --query Account --output text)\",\"TASK_TABLE\":\"${STACK}-tasks\",\"TASK_LOG_BUCKET\":\"${STACK}-logs-$(aws sts get-caller-identity --query Account --output text)\",\"MODEL_ID_SSM_PARAM\":\"/${STACK}/model-id\"}" \
  --region "$REGION" --output text --query "agentRuntimeId"

# CloudFront invalidation
DIST_ID=$(aws cloudformation describe-stack-resources --stack-name "$STACK" --region "$REGION" --query "StackResources[?LogicalResourceId=='Distribution'].PhysicalResourceId" --output text)
aws cloudfront create-invalidation --distribution-id "$DIST_ID" --paths "/*" --query "Invalidation.Status" --output text

echo ""
echo "═══════════════════════════════════════════════════════"
echo " ✅ Deploy complete!"
echo " URL: https://$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query "Stacks[0].Outputs[?OutputKey=='CloudFrontURL'].OutputValue" --output text | sed 's|https://||')"
echo "═══════════════════════════════════════════════════════"
