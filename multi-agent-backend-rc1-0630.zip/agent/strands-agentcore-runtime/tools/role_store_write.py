"""Role store write tools — create/update/delete roles in S3. Admin only."""
import os
import json
import logging
import boto3
import yaml
from strands import tool

logger = logging.getLogger(__name__)

BUCKET = os.getenv("ROLE_STORE_BUCKET", "")
REGION = os.getenv("AWS_REGION", "us-west-2")


def _s3():
    return boto3.client("s3", region_name=REGION)


def _parse_frontmatter(content: str) -> dict:
    """Extract YAML frontmatter metadata from markdown content."""
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            return yaml.safe_load(parts[1]) or {}
    return {}


@tool
def create_role(project_id: str, role_id: str, content: str) -> str:
    """Create a new role definition in the store.

    Args:
        project_id: Project ID to create the role in
        role_id: Unique role identifier
        content: Full markdown content with YAML frontmatter
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    s3 = _s3()
    key = f"{project_id}/{role_id}.md"
    try:
        s3.head_object(Bucket=BUCKET, Key=key)
        return f"Error: Role '{role_id}' already exists. Use update_role instead."
    except s3.exceptions.ClientError:
        pass
    s3.put_object(Bucket=BUCKET, Key=key, Body=content.encode("utf-8"), ContentType="text/markdown")
    _rebuild_index(s3, project_id)
    return f"Created role '{role_id}' in project '{project_id}'."


@tool
def update_role(project_id: str, role_id: str, content: str) -> str:
    """Update an existing role definition.

    Args:
        project_id: Project ID containing the role
        role_id: Role identifier to update
        content: New full markdown content with YAML frontmatter
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    s3 = _s3()
    key = f"{project_id}/{role_id}.md"
    s3.put_object(Bucket=BUCKET, Key=key, Body=content.encode("utf-8"), ContentType="text/markdown")
    _rebuild_index(s3, project_id)
    return f"Updated role '{role_id}' in project '{project_id}'."


@tool
def delete_role(project_id: str, role_id: str) -> str:
    """Delete a role definition from the store.

    Args:
        project_id: Project ID containing the role
        role_id: Role identifier to delete
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    s3 = _s3()
    key = f"{project_id}/{role_id}.md"
    s3.delete_object(Bucket=BUCKET, Key=key)
    _rebuild_index(s3, project_id)
    return f"Deleted role '{role_id}' from project '{project_id}'."


@tool
def regenerate_index(project_id: str) -> str:
    """Regenerate the _index.json for a project by scanning all .md files.

    Args:
        project_id: Project ID to regenerate index for
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    _rebuild_index(_s3(), project_id)
    return f"Regenerated index for project '{project_id}'."


def _rebuild_index(s3, project_id: str):
    """Scan all .md files in project prefix and rebuild _index.json."""
    prefix = f"{project_id}/"
    index = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=BUCKET, Prefix=prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if not key.endswith(".md"):
                continue
            try:
                body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
                meta = _parse_frontmatter(body)
                rid = key[len(prefix):].removesuffix(".md")
                index.append({
                    "role_id": meta.get("role_id", rid),
                    "description": meta.get("description", ""),
                    "tags": meta.get("tags", []),
                })
            except Exception as e:
                logger.warning(f"Failed to index {key}: {e}")

    index_key = f"{project_id}/_index.json"
    s3.put_object(Bucket=BUCKET, Key=index_key, Body=json.dumps(index, indent=2).encode("utf-8"), ContentType="application/json")
