"""Pipeline orchestration tools — used by the supervisor agent."""
import os
import json
import logging
import time
from datetime import datetime
import boto3
from strands import tool

logger = logging.getLogger(__name__)

TASK_TABLE = os.getenv("TASK_TABLE", "")
TASK_LOG_BUCKET = os.getenv("TASK_LOG_BUCKET", "")
REGION = os.getenv("AWS_REGION", "us-west-2")
TTL_HOURS = 48


def _ddb():
    return boto3.resource("dynamodb", region_name=REGION).Table(TASK_TABLE)


def _s3():
    return boto3.client("s3", region_name=REGION)


@tool
def invoke_role(role_id: str, input_text: str, context: str = "") -> str:
    """Invoke another role's agent within this session and return its response.

    Calls the role directly via Bedrock InvokeModel with the role's steering as system prompt.
    Use this to delegate work to specialist roles (PM, Architect, Dev, QA, CloudOps, Auditor).

    Args:
        role_id: The role to invoke (e.g. "pm", "architect", "full-stack-dev", "qa", "cloudops", "compliance-auditor")
        input_text: The task/prompt for this role
        context: Previous role's output to pass as context (optional)

    Returns:
        The role's full response text
    """
    import yaml
    import boto3

    # Load role steering from S3
    bucket = os.getenv("ROLE_STORE_BUCKET", "")
    region = os.getenv("AWS_REGION", "us-west-2")
    model_id = os.getenv("MODEL_ID", "us.anthropic.claude-sonnet-4-6")

    system_prompt = f"You are a specialist with role '{role_id}'. Complete the task thoroughly."

    if bucket:
        s3 = boto3.client("s3", region_name=region)
        # Try _global first, then project
        for prefix in ["_global", "plx-msp-checker"]:
            try:
                body = s3.get_object(Bucket=bucket, Key=f"{prefix}/{role_id}.md")["Body"].read().decode("utf-8")
                # Parse frontmatter
                if body.startswith("---"):
                    parts = body.split("---", 2)
                    if len(parts) >= 3:
                        meta = yaml.safe_load(parts[1]) or {}
                        system_prompt = parts[2].strip()
                        model_id = meta.get("model_id", model_id)
                break
            except Exception:
                continue

    # Build user message
    full_input = ""
    if context:
        full_input += f"## Input from previous stage\n\n{context}\n\n---\n\n"
    full_input += f"## Your Task\n\n{input_text}"

    # Direct Bedrock InvokeModel call (no nested Agent)
    try:
        import json
        bedrock = boto3.client("bedrock-runtime", region_name=region)
        resp = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 4096,
                "system": system_prompt,
                "messages": [{"role": "user", "content": full_input}],
            }),
        )
        result_body = json.loads(resp["body"].read())
        result = result_body["content"][0]["text"]
        logger.info(f"[invoke_role] {role_id} completed, len={len(result)}")
        return result
    except Exception as e:
        logger.error(f"[invoke_role] {role_id} failed: {e}")
        return f"Error invoking {role_id}: {e}"


@tool
def update_pipeline_status(run_id: str, stage: int, total: int,
                           role_id: str, role_name: str, status: str,
                           summary: str = "") -> str:
    """Update pipeline progress in DynamoDB so the frontend can track it.

    Call this BEFORE starting a stage (status="running") and AFTER completing it (status="done").
    Call with stage=0 and status="complete" or "error" to mark the entire pipeline.

    Args:
        run_id: Pipeline run identifier
        stage: Current stage number (1-6), or 0 for overall pipeline status
        total: Total number of stages (usually 6)
        role_id: The role executing this stage
        role_name: Display name of the role (e.g. "PM", "Architect")
        status: "running" | "done" | "error" | "complete"
        summary: Brief output summary for this stage (first 500 chars of output)

    Returns:
        Confirmation message
    """
    if not TASK_TABLE:
        return "Warning: TASK_TABLE not configured, status not persisted"

    ddb = _ddb()
    ttl = int(time.time()) + TTL_HOURS * 3600
    now = datetime.utcnow().isoformat()

    try:
        if stage == 0:
            # Update overall pipeline meta
            ddb.put_item(Item={
                "sessionId": f"pipeline#{run_id}",
                "taskId": "meta",
                "status": status,
                "current_stage": total if status == "complete" else 0,
                "total": total,
                "updated_at": now,
                "ttl": ttl,
            })
        else:
            # Update specific stage
            item = {
                "sessionId": f"pipeline#{run_id}",
                "taskId": f"stage#{stage:02d}",
                "role_id": role_id,
                "role_name": role_name,
                "status": status,
                "summary": summary[:2000],
                "ttl": ttl,
            }
            if status == "running":
                item["started_at"] = now
            elif status in ("done", "error"):
                item["completed_at"] = now

            ddb.put_item(Item=item)

            # Also update meta with current_stage
            ddb.update_item(
                Key={"sessionId": f"pipeline#{run_id}", "taskId": "meta"},
                UpdateExpression="SET current_stage = :s, updated_at = :t, #st = :status",
                ExpressionAttributeNames={"#st": "status"},
                ExpressionAttributeValues={
                    ":s": stage,
                    ":t": now,
                    ":status": "running" if status == "running" else "running",
                },
            )

        return f"Pipeline {run_id} stage {stage}/{total} → {status}"
    except Exception as e:
        logger.error(f"[update_pipeline_status] failed: {e}")
        return f"Error updating status: {e}"


@tool
def save_artifact(run_id: str, stage: int, role_id: str, content: str) -> str:
    """Save stage output to S3 as a markdown file.

    Saves to: s3://{TASK_LOG_BUCKET}/pipelines/{run_id}/{stage:02d}-{role_id}.md

    Args:
        run_id: Pipeline run identifier
        stage: Stage number (1-6)
        role_id: Role that produced this output
        content: Full output content to save

    Returns:
        S3 path where the artifact was saved
    """
    if not TASK_LOG_BUCKET:
        return "Warning: TASK_LOG_BUCKET not configured, artifact not saved"

    key = f"pipelines/{run_id}/{stage:02d}-{role_id}.md"
    try:
        _s3().put_object(
            Bucket=TASK_LOG_BUCKET,
            Key=key,
            Body=content.encode("utf-8"),
            ContentType="text/markdown",
        )
        logger.info(f"[save_artifact] saved s3://{TASK_LOG_BUCKET}/{key}")
        return f"Saved to s3://{TASK_LOG_BUCKET}/{key}"
    except Exception as e:
        logger.error(f"[save_artifact] failed: {e}")
        return f"Error saving artifact: {e}"
