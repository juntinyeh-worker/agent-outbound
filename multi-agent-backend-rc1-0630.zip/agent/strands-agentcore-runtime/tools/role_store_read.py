"""Role store read tools — query roles from S3 bucket."""
import os
import json
import logging
import boto3
from strands import tool

logger = logging.getLogger(__name__)

BUCKET = os.getenv("ROLE_STORE_BUCKET", "")
REGION = os.getenv("AWS_REGION", "us-west-2")


def _s3():
    return boto3.client("s3", region_name=REGION)


def _load_index(project_id: str) -> list[dict]:
    """Load _index.json for a project from S3."""
    key = f"{project_id}/_index.json"
    try:
        body = _s3().get_object(Bucket=BUCKET, Key=key)["Body"].read()
        return json.loads(body)
    except Exception as e:
        logger.warning(f"Failed to load index {key}: {e}")
        return []


@tool
def search_roles(query: str, tags: str = "", project_id: str = "") -> str:
    """Search roles by query string and optional tags.

    Args:
        query: Search term to match against role_id and description
        tags: Comma-separated tags to filter by (optional)
        project_id: Project ID to scope search (optional, searches all if empty)
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"

    s3 = _s3()
    projects = [project_id] if project_id else []
    if not projects:
        try:
            resp = s3.list_objects_v2(Bucket=BUCKET, Delimiter="/")
            projects = [p["Prefix"].rstrip("/") for p in resp.get("CommonPrefixes", [])]
        except Exception as e:
            return f"Error listing projects: {e}"

    tag_filter = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
    results = []
    for pid in projects:
        for role in _load_index(pid):
            match = query.lower() in role.get("role_id", "").lower() or query.lower() in role.get("description", "").lower()
            if not match:
                continue
            if tag_filter and not any(t in role.get("tags", []) for t in tag_filter):
                continue
            role["project_id"] = pid
            results.append(role)

    return json.dumps(results, indent=2) if results else "No roles found matching query."


@tool
def get_role_detail(role_id: str, project_id: str) -> str:
    """Get full role definition (markdown content) for a specific role.

    Args:
        role_id: The role identifier
        project_id: The project ID containing the role
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    key = f"{project_id}/{role_id}.md"
    try:
        body = _s3().get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
        return body
    except Exception as e:
        return f"Error loading role {role_id}: {e}"


@tool
def list_project_roles(project_id: str) -> str:
    """List all roles in a project.

    Args:
        project_id: The project ID to list roles for
    """
    if not BUCKET:
        return "Error: ROLE_STORE_BUCKET not configured"
    roles = _load_index(project_id)
    if not roles:
        return f"No roles found for project '{project_id}'."
    return json.dumps(roles, indent=2)
