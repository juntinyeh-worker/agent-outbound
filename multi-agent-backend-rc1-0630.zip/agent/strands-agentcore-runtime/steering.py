"""Steering file loader — loads .md steering files on demand.

Supports loading from:
- Local path (e.g. /app/steering/ or relative ./steering/)
- S3 path (e.g. s3://bucket/steering/)

Steering files are loaded dynamically by the agent via a tool call,
keeping the system prompt small and preserving context for tool responses.
"""
import os
import logging
import boto3

logger = logging.getLogger(__name__)

STEERING_PATH = os.getenv("STEERING_PATH", "/app/steering")
STEERING_S3_URI = os.getenv("STEERING_S3_URI", "")  # e.g. s3://bucket/prefix/steering/


def list_steering_files() -> dict[str, str]:
    """Return a dict of {name: first_line_description} for all available steering files."""
    if STEERING_S3_URI:
        return _list_from_s3(STEERING_S3_URI)
    if os.path.isdir(STEERING_PATH):
        return _list_from_local(STEERING_PATH)
    logger.warning(f"No steering files found at {STEERING_PATH} or S3")
    return {}


def _validate_name(name: str) -> str | None:
    """Validate steering file name. Returns error string if invalid, None if OK."""
    if ".." in name or name.startswith("/") or name.startswith("\\"):
        return "Error: Invalid steering file name — path traversal not allowed"
    if any(ord(c) < 32 for c in name):
        return "Error: Invalid steering file name — control characters not allowed"
    return None


def load_steering_file(name: str) -> str:
    """Load a single steering file by name (without .md extension)."""
    error = _validate_name(name)
    if error:
        return error
    if STEERING_S3_URI:
        return _load_one_from_s3(STEERING_S3_URI, name)
    if os.path.isdir(STEERING_PATH):
        return _load_one_from_local(STEERING_PATH, name)
    return f"Error: No steering source configured"


def _list_from_local(path: str) -> dict[str, str]:
    """List all .md files with their first heading or line as description."""
    index = {}
    for root, _, files in sorted(os.walk(path)):
        for fname in sorted(files):
            if not fname.endswith(".md"):
                continue
            fpath = os.path.join(root, fname)
            rel = os.path.relpath(fpath, path)
            name = rel.removesuffix(".md")
            try:
                with open(fpath, "r") as f:
                    first_line = ""
                    for line in f:
                        line = line.strip()
                        if line:
                            first_line = line.lstrip("# ")
                            break
                index[name] = first_line
            except Exception as e:
                logger.warning(f"Failed to read {fpath}: {e}")
    return index


def _load_one_from_local(path: str, name: str) -> str:
    """Load a single .md file from local path."""
    real_base = os.path.realpath(path)
    # Try exact match, then search recursively
    candidates = [
        os.path.join(path, f"{name}.md"),
        os.path.join(path, name, "index.md"),
    ]
    # Also search recursively for the name
    for root, _, files in os.walk(path):
        for fname in files:
            if fname == f"{name}.md":
                candidates.append(os.path.join(root, fname))

    for fpath in candidates:
        if os.path.isfile(fpath):
            # Containment check — ensure resolved path stays within steering dir
            if not os.path.realpath(fpath).startswith(real_base):
                return "Error: Path escapes steering directory"
            try:
                with open(fpath, "r") as f:
                    return f.read().strip()
            except Exception as e:
                return f"Error reading {fpath}: {e}"

    available = list(_list_from_local(path).keys())
    return f"Error: Steering file '{name}' not found. Available: {available}"


def _list_from_s3(s3_uri: str) -> dict[str, str]:
    """List all .md files from S3 with first line as description."""
    s3 = boto3.client("s3", region_name=os.getenv("AWS_REGION", "us-west-2"))
    bucket, prefix = _parse_s3_uri(s3_uri)
    index = {}
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if not key.endswith(".md"):
                    continue
                rel = key[len(prefix):]
                name = rel.removesuffix(".md")
                try:
                    # Read just the first 200 bytes for description
                    body = s3.get_object(Bucket=bucket, Key=key, Range="bytes=0-200")["Body"].read().decode("utf-8")
                    first_line = ""
                    for line in body.splitlines():
                        line = line.strip()
                        if line:
                            first_line = line.lstrip("# ")
                            break
                    index[name] = first_line
                except Exception:
                    index[name] = "(no description)"
    except Exception as e:
        logger.warning(f"Failed to list S3 steering files: {e}")
    return index


def _load_one_from_s3(s3_uri: str, name: str) -> str:
    """Load a single .md file from S3."""
    s3 = boto3.client("s3", region_name=os.getenv("AWS_REGION", "us-west-2"))
    bucket, prefix = _parse_s3_uri(s3_uri)
    key = f"{prefix}{name}.md"
    try:
        body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode("utf-8").strip()
        return body
    except s3.exceptions.NoSuchKey:
        available = list(_list_from_s3(s3_uri).keys())
        return f"Error: Steering file '{name}' not found. Available: {available}"
    except Exception as e:
        return f"Error loading s3://{bucket}/{key}: {e}"


def _parse_s3_uri(s3_uri: str) -> tuple[str, str]:
    """Parse s3://bucket/prefix/ into (bucket, prefix)."""
    parts = s3_uri.replace("s3://", "").split("/", 1)
    bucket = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    if prefix and not prefix.endswith("/"):
        prefix += "/"
    return bucket, prefix
