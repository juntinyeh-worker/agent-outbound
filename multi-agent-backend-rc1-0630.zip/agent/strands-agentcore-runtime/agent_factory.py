"""Agent factory — creates a Strands agent from a role definition stored in S3."""
import os
import logging
import yaml
import boto3
from strands import Agent
from strands.models import BedrockModel
from strands_tools import think
from tools.aws_api import call_aws, call_boto3, get_steering
from tools.role_store_read import search_roles, get_role_detail, list_project_roles
from tools.role_store_write import create_role, update_role, delete_role, regenerate_index
from tools.pipeline_tools import invoke_role, update_pipeline_status, save_artifact

logger = logging.getLogger(__name__)

BUCKET = os.getenv("ROLE_STORE_BUCKET", "")
REGION = os.getenv("AWS_REGION", "us-west-2")
DEFAULT_MODEL_ID = "us.anthropic.claude-sonnet-4-6"

# Tool registry — maps tool name strings to tool functions
TOOL_REGISTRY = {
    "call_aws": call_aws,
    "call_boto3": call_boto3,
    "get_steering": get_steering,
    "think": think,
    "search_roles": search_roles,
    "get_role_detail": get_role_detail,
    "list_project_roles": list_project_roles,
    "create_role": create_role,
    "update_role": update_role,
    "delete_role": delete_role,
    "regenerate_index": regenerate_index,
    "invoke_role": invoke_role,
    "update_pipeline_status": update_pipeline_status,
    "save_artifact": save_artifact,
}

# Admin-only tools
ADMIN_TOOLS = {"create_role", "update_role", "delete_role", "regenerate_index"}

# Supervisor-only tools
SUPERVISOR_TOOLS = {"invoke_role", "update_pipeline_status", "save_artifact"}


def _load_role_from_s3(role_id: str) -> str | None:
    """Load role .md file from S3 bucket. Searches all project prefixes."""
    if not BUCKET:
        logger.warning(f"ROLE_STORE_BUCKET not set, cannot load role {role_id}")
        return None
    s3 = boto3.client("s3", region_name=REGION)
    # Try direct key first (role_id might include project prefix)
    if "/" in role_id:
        key = f"{role_id}.md"
    else:
        # Try _global first (system roles like supervisor, admin)
        try:
            key = f"_global/{role_id}.md"
            body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
            logger.info(f"Loaded role '{role_id}' from s3://{BUCKET}/{key}")
            return body
        except Exception:
            pass

        # Search across all prefixes
        try:
            resp = s3.list_objects_v2(Bucket=BUCKET, Delimiter="/")
            for prefix_obj in resp.get("CommonPrefixes", []):
                prefix = prefix_obj["Prefix"]
                if prefix == "_global/":
                    continue  # already tried
                key = f"{prefix}{role_id}.md"
                try:
                    body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
                    logger.info(f"Loaded role '{role_id}' from s3://{BUCKET}/{key}")
                    return body
                except Exception:
                    continue
            logger.warning(f"Role '{role_id}' not found in any S3 prefix")
            return None
        except Exception as e:
            logger.warning(f"Error searching for role {role_id}: {e}")
            return None

    try:
        body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
        return body
    except Exception as e:
        logger.warning(f"Failed to load role {role_id} from S3: {e}")
        return None


def _parse_role_md(content: str) -> tuple[dict, str]:
    """Parse YAML frontmatter and markdown body from role content."""
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            meta = yaml.safe_load(parts[1]) or {}
            body = parts[2].strip()
            return meta, body
    return {}, content.strip()


def create_agent_for_role(role_id: str) -> Agent:
    """Create a Strands Agent configured for the given role_id.

    Loads role definition from S3, parses frontmatter for config,
    and returns an Agent with scoped tools.
    """
    content = _load_role_from_s3(role_id)

    if content:
        meta, system_prompt = _parse_role_md(content)
    else:
        # Fallback: no role found, use default supervisor behavior
        logger.warning(f"Role '{role_id}' not found in S3, using default agent")
        meta = {}
        system_prompt = f"You are an agent with role '{role_id}'. Help the user with their request."

    model_id = meta.get("model_id", os.getenv("MODEL_ID", DEFAULT_MODEL_ID))
    tool_names = meta.get("tools", ["call_aws", "call_boto3", "get_steering", "think"])

    # Scope tools: only include admin tools if role_id is 'admin'
    # Only include supervisor tools if role_id is 'supervisor'
    tools = []
    for name in tool_names:
        if name in ADMIN_TOOLS and role_id != "admin":
            continue
        if name in SUPERVISOR_TOOLS and role_id != "supervisor":
            continue
        if name in TOOL_REGISTRY:
            tools.append(TOOL_REGISTRY[name])

    # Always include think
    if think not in tools:
        tools.append(think)

    bedrock_model = BedrockModel(model_id=model_id, region_name=REGION)

    return Agent(model=bedrock_model, system_prompt=system_prompt, tools=tools)
