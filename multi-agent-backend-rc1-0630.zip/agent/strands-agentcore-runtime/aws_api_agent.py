"""AWS API Agent using Strands with subprocess-isolated AWS API calls.

All AWS API calls (boto3 and CLI) run as subprocesses so a failed call
never crashes the agent process. Supports cross-account via AWS_ASSUME_ROLE_ARN.

Supports steering files (.md) for guiding WA review flows.
DEMO_MODE: When enabled, all AWS calls are simulated with mock responses.
"""
import os
import subprocess
import sys
import json
import logging
from strands import Agent, tool
from strands.models import BedrockModel
from strands_tools import think
from steering import list_steering_files, load_steering_file

logger = logging.getLogger(__name__)
DEFAULT_MODEL_ID = "us.anthropic.claude-sonnet-4-6"
MODEL_ID_SSM_PARAM = os.getenv("MODEL_ID_SSM_PARAM", "")
BOTO3_TIMEOUT = 120
DEMO_MODE = os.getenv("DEMO_MODE", "false").lower() == "true"

# ============ DEMO MODE MOCK DATA ============

MOCK_RESPONSES = {
    ("sts", "get_caller_identity"): {
        "UserId": "AROAEXAMPLE12345:demo-session",
        "Account": "123456789012",
        "Arn": "arn:aws:sts::123456789012:assumed-role/wa-ai-review-role/demo-session"
    },
    ("iam", "list_attached_role_policies"): {
        "AttachedPolicies": [
            {"PolicyName": "ReadOnlyAccess", "PolicyArn": "arn:aws:iam::aws:policy/ReadOnlyAccess"}
        ]
    },
    ("ec2", "describe_instances"): {
        "Reservations": [
            {"Instances": [
                {"InstanceId": "i-0a1b2c3d4e5f60001", "InstanceType": "t3.large", "State": {"Name": "running"}, "Tags": [{"Key": "Name", "Value": "web-prod-1"}], "SubnetId": "subnet-0abc1234", "VpcId": "vpc-0def5678", "SecurityGroups": [{"GroupId": "sg-0aaa1111", "GroupName": "web-sg"}], "IamInstanceProfile": {"Arn": "arn:aws:iam::123456789012:instance-profile/web-role"}},
                {"InstanceId": "i-0a1b2c3d4e5f60002", "InstanceType": "m5.xlarge", "State": {"Name": "running"}, "Tags": [{"Key": "Name", "Value": "api-prod-1"}], "SubnetId": "subnet-0abc1234", "VpcId": "vpc-0def5678", "SecurityGroups": [{"GroupId": "sg-0bbb2222", "GroupName": "api-sg"}], "IamInstanceProfile": {"Arn": "arn:aws:iam::123456789012:instance-profile/api-role"}},
                {"InstanceId": "i-0a1b2c3d4e5f60003", "InstanceType": "t3.micro", "State": {"Name": "running"}, "Tags": [{"Key": "Name", "Value": "bastion-host"}], "SubnetId": "subnet-0xyz9999", "VpcId": "vpc-0def5678", "SecurityGroups": [{"GroupId": "sg-0ccc3333", "GroupName": "bastion-sg"}]}
            ]}
        ]
    },
    ("ec2", "describe_vpcs"): {
        "Vpcs": [
            {"VpcId": "vpc-0def5678", "CidrBlock": "10.0.0.0/16", "State": "available", "Tags": [{"Key": "Name", "Value": "production-vpc"}], "IsDefault": False},
            {"VpcId": "vpc-0default1", "CidrBlock": "172.31.0.0/16", "State": "available", "IsDefault": True}
        ]
    },
    ("ec2", "describe_security_groups"): {
        "SecurityGroups": [
            {"GroupId": "sg-0aaa1111", "GroupName": "web-sg", "Description": "Web tier SG", "IpPermissions": [{"IpProtocol": "tcp", "FromPort": 443, "ToPort": 443, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}, {"IpProtocol": "tcp", "FromPort": 80, "ToPort": 80, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}]},
            {"GroupId": "sg-0bbb2222", "GroupName": "api-sg", "Description": "API tier SG", "IpPermissions": [{"IpProtocol": "tcp", "FromPort": 8080, "ToPort": 8080, "IpRanges": [{"CidrIp": "10.0.0.0/16"}]}]},
            {"GroupId": "sg-0ccc3333", "GroupName": "bastion-sg", "Description": "Bastion SG", "IpPermissions": [{"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "FINDING: SSH open to world"}]}]}
        ]
    },
    ("ec2", "describe_flow_logs"): {
        "FlowLogs": [
            {"FlowLogId": "fl-0abc1234", "ResourceId": "vpc-0def5678", "TrafficType": "ALL", "LogDestinationType": "cloud-watch-logs", "FlowLogStatus": "ACTIVE"}
        ]
    },
    ("ec2", "describe_volumes"): {
        "Volumes": [
            {"VolumeId": "vol-0aaa1111", "Encrypted": True, "Size": 100, "State": "in-use", "VolumeType": "gp3"},
            {"VolumeId": "vol-0bbb2222", "Encrypted": True, "Size": 50, "State": "in-use", "VolumeType": "gp3"},
            {"VolumeId": "vol-0ccc3333", "Encrypted": False, "Size": 20, "State": "available", "VolumeType": "gp2"}
        ]
    },
    ("s3", "list_buckets"): {
        "Buckets": [
            {"Name": "prod-data-lake-123456789012", "CreationDate": "2024-01-15T00:00:00Z"},
            {"Name": "prod-logs-123456789012", "CreationDate": "2024-02-20T00:00:00Z"},
            {"Name": "staging-assets-123456789012", "CreationDate": "2024-06-01T00:00:00Z"},
            {"Name": "public-website-assets", "CreationDate": "2024-03-10T00:00:00Z"}
        ]
    },
    ("s3", "get_bucket_encryption"): {
        "ServerSideEncryptionConfiguration": {
            "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "aws:kms", "KMSMasterKeyID": "arn:aws:kms:us-west-2:123456789012:key/mrk-1234abcd"}}]
        }
    },
    ("s3", "get_public_access_block"): {
        "PublicAccessBlockConfiguration": {"BlockPublicAcls": True, "IgnorePublicAcls": True, "BlockPublicPolicy": True, "RestrictPublicBuckets": True}
    },
    ("s3", "get_bucket_versioning"): {"Status": "Enabled"},
    ("s3", "get_bucket_logging"): {"LoggingEnabled": {"TargetBucket": "prod-logs-123456789012", "TargetPrefix": "s3-access-logs/"}},
    ("iam", "get_account_summary"): {
        "SummaryMap": {"Users": 8, "Groups": 3, "Roles": 25, "Policies": 15, "MFADevicesInUse": 6, "AccountMFAEnabled": 1, "AccessKeysPerUserQuota": 2}
    },
    ("iam", "list_users"): {
        "Users": [
            {"UserName": "admin-user", "UserId": "AIDAEXAMPLE1", "CreateDate": "2023-06-01T00:00:00Z", "PasswordLastUsed": "2026-06-17T10:00:00Z"},
            {"UserName": "dev-sarah", "UserId": "AIDAEXAMPLE2", "CreateDate": "2024-01-15T00:00:00Z", "PasswordLastUsed": "2026-06-18T08:00:00Z"},
            {"UserName": "ci-deploy", "UserId": "AIDAEXAMPLE3", "CreateDate": "2024-03-01T00:00:00Z"}
        ]
    },
    ("iam", "list_mfa_devices"): {"MFADevices": []},
    ("iam", "list_access_keys"): {
        "AccessKeyMetadata": [{"AccessKeyId": "AKIAEXAMPLE1234", "Status": "Active", "CreateDate": "2023-06-01T00:00:00Z"}]
    },
    ("iam", "generate_credential_report"): {"State": "COMPLETE"},
    ("iam", "get_credential_report"): {
        "Content": "user,arn,mfa_active,access_key_1_active,access_key_1_last_rotated\nadmin-user,arn:aws:iam::123456789012:user/admin-user,true,true,2025-01-15T00:00:00Z\ndev-sarah,arn:aws:iam::123456789012:user/dev-sarah,true,true,2026-05-01T00:00:00Z\nci-deploy,arn:aws:iam::123456789012:user/ci-deploy,false,true,2024-03-01T00:00:00Z",
        "ReportFormat": "text/csv", "GeneratedTime": "2026-06-18T08:00:00Z"
    },
    ("cloudtrail", "describe_trails"): {
        "trailList": [
            {"Name": "org-trail", "S3BucketName": "prod-logs-123456789012", "IsMultiRegionTrail": True, "LogFileValidationEnabled": True, "HasCustomEventSelectors": True, "IsOrganizationTrail": True, "HomeRegion": "us-west-2"}
        ]
    },
    ("cloudtrail", "get_trail_status"): {"IsLogging": True, "LatestDeliveryTime": "2026-06-18T08:10:00Z"},
    ("kms", "list_keys"): {
        "Keys": [
            {"KeyId": "mrk-1234abcd", "KeyArn": "arn:aws:kms:us-west-2:123456789012:key/mrk-1234abcd"},
            {"KeyId": "mrk-5678efgh", "KeyArn": "arn:aws:kms:us-west-2:123456789012:key/mrk-5678efgh"}
        ]
    },
    ("kms", "describe_key"): {
        "KeyMetadata": {"KeyId": "mrk-1234abcd", "KeyState": "Enabled", "KeyManager": "CUSTOMER", "KeySpec": "SYMMETRIC_DEFAULT", "KeyUsage": "ENCRYPT_DECRYPT", "MultiRegion": True, "Description": "Production data encryption key", "Enabled": True, "KeyRotationStatus": True}
    },
    ("kms", "get_key_rotation_status"): {"KeyRotationEnabled": True},
    ("guardduty", "list_detectors"): {"DetectorIds": ["d0abc1234567890"]},
    ("guardduty", "get_detector"): {"Status": "ENABLED", "FindingPublishingFrequency": "FIFTEEN_MINUTES", "CreatedAt": "2024-01-01T00:00:00Z"},
    ("guardduty", "list_findings"): {"FindingIds": ["f0aaa1111", "f0bbb2222"]},
    ("guardduty", "get_findings"): {
        "Findings": [
            {"Id": "f0aaa1111", "Type": "UnauthorizedAccess:EC2/SSHBruteForce", "Severity": 5.0, "Title": "SSH brute force attack on i-0a1b2c3d4e5f60003", "Description": "Multiple failed SSH login attempts detected", "Resource": {"ResourceType": "Instance", "InstanceDetails": {"InstanceId": "i-0a1b2c3d4e5f60003"}}, "CreatedAt": "2026-06-17T22:00:00Z"},
            {"Id": "f0bbb2222", "Type": "Recon:EC2/PortProbeUnprotectedPort", "Severity": 2.0, "Title": "Port probe on unprotected port", "Description": "EC2 instance port 22 is being probed", "Resource": {"ResourceType": "Instance", "InstanceDetails": {"InstanceId": "i-0a1b2c3d4e5f60003"}}, "CreatedAt": "2026-06-18T01:00:00Z"}
        ]
    },
    ("config", "describe_config_rules"): {
        "ConfigRules": [
            {"ConfigRuleName": "s3-bucket-public-read-prohibited", "ConfigRuleState": "ACTIVE", "Compliance": {"ComplianceType": "COMPLIANT"}},
            {"ConfigRuleName": "encrypted-volumes", "ConfigRuleState": "ACTIVE", "Compliance": {"ComplianceType": "NON_COMPLIANT"}},
            {"ConfigRuleName": "iam-root-access-key-check", "ConfigRuleState": "ACTIVE", "Compliance": {"ComplianceType": "COMPLIANT"}}
        ]
    },
    ("config", "describe_compliance_by_config_rule"): {
        "ComplianceByConfigRules": [
            {"ConfigRuleName": "s3-bucket-public-read-prohibited", "Compliance": {"ComplianceType": "COMPLIANT"}},
            {"ConfigRuleName": "encrypted-volumes", "Compliance": {"ComplianceType": "NON_COMPLIANT"}},
            {"ConfigRuleName": "iam-root-access-key-check", "Compliance": {"ComplianceType": "COMPLIANT"}}
        ]
    },
    ("ce", "get_cost_and_usage"): {
        "ResultsByTime": [
            {"TimePeriod": {"Start": "2026-01-01", "End": "2026-02-01"}, "Total": {"UnblendedCost": {"Amount": "4523.17", "Unit": "USD"}}},
            {"TimePeriod": {"Start": "2026-02-01", "End": "2026-03-01"}, "Total": {"UnblendedCost": {"Amount": "4891.42", "Unit": "USD"}}},
            {"TimePeriod": {"Start": "2026-03-01", "End": "2026-04-01"}, "Total": {"UnblendedCost": {"Amount": "5102.88", "Unit": "USD"}}},
            {"TimePeriod": {"Start": "2026-04-01", "End": "2026-05-01"}, "Total": {"UnblendedCost": {"Amount": "5467.23", "Unit": "USD"}}},
            {"TimePeriod": {"Start": "2026-05-01", "End": "2026-06-01"}, "Total": {"UnblendedCost": {"Amount": "5789.55", "Unit": "USD"}}},
            {"TimePeriod": {"Start": "2026-06-01", "End": "2026-06-18"}, "Total": {"UnblendedCost": {"Amount": "3421.09", "Unit": "USD"}}}
        ]
    },
    ("ce", "get_cost_forecast"): {
        "Total": {"Amount": "6150.00", "Unit": "USD"},
        "ForecastResultsByTime": [
            {"TimePeriod": {"Start": "2026-07-01", "End": "2026-08-01"}, "MeanValue": "6150.00"},
            {"TimePeriod": {"Start": "2026-08-01", "End": "2026-09-01"}, "MeanValue": "6320.00"},
            {"TimePeriod": {"Start": "2026-09-01", "End": "2026-10-01"}, "MeanValue": "6480.00"}
        ]
    },
    ("compute-optimizer", "get_recommendation_summaries"): {
        "recommendationSummaries": [
            {"accountId": "123456789012", "recommendationResourceType": "Ec2Instance", "summaries": [{"name": "OVER_PROVISIONED", "value": 2}, {"name": "OPTIMIZED", "value": 1}]},
            {"accountId": "123456789012", "recommendationResourceType": "EbsVolume", "summaries": [{"name": "NOT_OPTIMIZED", "value": 1}, {"name": "OPTIMIZED", "value": 2}]}
        ]
    },
    ("rds", "describe_db_clusters"): {
        "DBClusters": [
            {"DBClusterIdentifier": "prod-aurora-mysql", "Engine": "aurora-mysql", "EngineVersion": "8.0.mysql_aurora.3.04.0", "Status": "available", "StorageEncrypted": True, "KmsKeyId": "arn:aws:kms:us-west-2:123456789012:key/mrk-1234abcd", "MultiAZ": True, "DeletionProtection": True, "IAMDatabaseAuthenticationEnabled": True}
        ]
    },
    ("rds", "describe_db_instances"): {
        "DBInstances": [
            {"DBInstanceIdentifier": "prod-aurora-mysql-1", "DBClusterIdentifier": "prod-aurora-mysql", "DBInstanceClass": "db.r6g.large", "Engine": "aurora-mysql", "DBInstanceStatus": "available", "PubliclyAccessible": False, "AutoMinorVersionUpgrade": True}
        ]
    },
}

MOCK_CLI_RESPONSES = {
    "aws sts get-caller-identity": json.dumps(MOCK_RESPONSES[("sts", "get_caller_identity")], indent=2),
    "aws s3 ls": "2024-01-15 00:00:00 prod-data-lake-123456789012\n2024-02-20 00:00:00 prod-logs-123456789012\n2024-06-01 00:00:00 staging-assets-123456789012\n2024-03-10 00:00:00 public-website-assets",
    "aws ec2 describe-flow-logs": json.dumps(MOCK_RESPONSES[("ec2", "describe_flow_logs")], indent=2),
    "aws cloudtrail describe-trails": json.dumps(MOCK_RESPONSES[("cloudtrail", "describe_trails")], indent=2),
    "aws guardduty list-detectors": json.dumps(MOCK_RESPONSES[("guardduty", "list_detectors")], indent=2),
}


def _demo_boto3(service: str, operation: str, params: str) -> str:
    """Return mock response for a boto3 call in demo mode."""
    key = (service, operation)
    if key in MOCK_RESPONSES:
        return json.dumps(MOCK_RESPONSES[key], indent=2, default=str)
    # Fallback: return a plausible empty response
    return json.dumps({"message": f"(demo) No resources found for {service}.{operation}"}, indent=2)


def _demo_cli(command: str) -> str:
    """Return mock response for an AWS CLI call in demo mode."""
    # Try exact match first
    for prefix, response in MOCK_CLI_RESPONSES.items():
        if command.strip().startswith(prefix):
            return response
    # Try to map CLI to boto3 mock
    parts = command.strip().split()
    if len(parts) >= 3:
        svc = parts[1]
        op = parts[2].replace("-", "_")
        key = (svc, op)
        if key in MOCK_RESPONSES:
            return json.dumps(MOCK_RESPONSES[key], indent=2, default=str)
    return json.dumps({"message": f"(demo) Command executed successfully, no findings."}, indent=2)


def _build_env():
    """Build subprocess environment, propagating AWS creds and assume-role config."""
    env = os.environ.copy()
    # Ensure cross-account vars are always propagated
    for key in ("AWS_ASSUME_ROLE_ARN", "AWS_ASSUME_ROLE_SESSION_NAME", "AWS_ASSUME_ROLE_EXTERNAL_ID"):
        val = os.getenv(key)
        if val:
            env[key] = val
    return env


def _run_boto3_script(script: str, timeout: int = BOTO3_TIMEOUT) -> str:
    """Run a Python script in a subprocess that performs boto3 operations.

    Returns stdout on success, or a descriptive error string on failure.
    The agent process is never affected by exceptions in the subprocess.
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            env=_build_env(),
        )
        if result.returncode == 0:
            return result.stdout.strip() if result.stdout.strip() else "(no output)"
        else:
            stderr = result.stderr.strip()[:2000]
            return f"Error (exit {result.returncode}): {stderr}"
    except subprocess.TimeoutExpired:
        return f"Error: boto3 call timed out after {timeout} seconds"
    except Exception as e:
        return f"Error launching subprocess: {str(e)}"


def get_model_id():
    """Get model ID: SSM param > MODEL_ID env > default.

    SSM lookup runs in a subprocess so a failure cannot crash the agent.
    """
    if MODEL_ID_SSM_PARAM:
        script = f"""
import boto3, os, json
region = os.getenv("AWS_REGION", "us-west-2")
ssm = boto3.client("ssm", region_name=region)
resp = ssm.get_parameter(Name={MODEL_ID_SSM_PARAM!r}, WithDecryption=False)
print(resp["Parameter"]["Value"])
"""
        value = _run_boto3_script(script, timeout=10)
        if not value.startswith("Error") and value and value != "PLACEHOLDER":
            logger.info(f"Model ID from SSM ({MODEL_ID_SSM_PARAM}): {value}")
            return value
        else:
            logger.warning(f"Failed to read model from SSM: {value}")

    model = os.getenv("MODEL_ID", DEFAULT_MODEL_ID)
    logger.info(f"Using model: {model}")
    return model


def _get_assumed_role_creds_env(env: dict) -> dict:
    """If AWS_ASSUME_ROLE_ARN is set, assume the role in a subprocess and inject temp creds into env.

    Returns the env dict with AWS_ACCESS_KEY_ID/SECRET/TOKEN set, or unmodified env on failure.
    """
    role_arn = env.get("AWS_ASSUME_ROLE_ARN", "")
    if not role_arn:
        return env

    script = f"""
import boto3, os, json
region = os.getenv("AWS_REGION", "us-west-2")
sts = boto3.client("sts", region_name=region)
creds = sts.assume_role(
    RoleArn={role_arn!r},
    RoleSessionName=os.getenv("AWS_ASSUME_ROLE_SESSION_NAME", "agent-scan"),
)["Credentials"]
print(json.dumps({{
    "AccessKeyId": creds["AccessKeyId"],
    "SecretAccessKey": creds["SecretAccessKey"],
    "SessionToken": creds["SessionToken"],
}}))
"""
    try:
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=15,
            env=env,
        )
        if result.returncode == 0:
            creds = json.loads(result.stdout.strip())
            env = env.copy()
            env["AWS_ACCESS_KEY_ID"] = creds["AccessKeyId"]
            env["AWS_SECRET_ACCESS_KEY"] = creds["SecretAccessKey"]
            env["AWS_SESSION_TOKEN"] = creds["SessionToken"]
            # Remove role ARN so CLI doesn't try to re-assume
            env.pop("AWS_ASSUME_ROLE_ARN", None)
            return env
        else:
            logger.warning(f"AssumeRole failed: {result.stderr[:200]}")
    except Exception as e:
        logger.warning(f"AssumeRole subprocess error: {e}")

    return env


@tool
def call_aws(command: str) -> str:
    """Execute an AWS CLI command and return the output.

    Args:
        command: The full AWS CLI command starting with 'aws'. E.g. 'aws s3 ls'
    """
    if not command.strip().startswith("aws"):
        return "Error: Command must start with 'aws'"

    if DEMO_MODE:
        logger.info(f"[DEMO] call_aws: {command}")
        result = _demo_cli(command)
        return f"[SIMULATED] $ {command}\n\n{result}"

    demo_read_only = os.getenv("DEMO_READ_ONLY", "false").lower() == "true"
    if demo_read_only:
        parts = command.split()
        write_verbs = ["create", "delete", "put", "update", "remove", "terminate", "start", "stop", "modify"]
        for verb in write_verbs:
            if verb in parts:
                return f"Error: Write operation '{verb}' is not allowed in read-only demo mode."

    env = _get_assumed_role_creds_env(_build_env())

    try:
        result = subprocess.run(
            command.split(),
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
        if result.returncode == 0:
            return result.stdout[:10000] if result.stdout else "(no output)"
        else:
            return f"Error (exit {result.returncode}): {result.stderr[:2000]}"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out after 60 seconds"
    except Exception as e:
        return f"Error executing command: {str(e)}"


@tool
def call_boto3(service: str, operation: str, params: str = "{}") -> str:
    """Execute an AWS API call using boto3 in an isolated subprocess.

    Supports cross-account calls when AWS_ASSUME_ROLE_ARN is set.

    Args:
        service: AWS service name (e.g. 's3', 'ec2', 'iam')
        operation: API operation (e.g. 'list_buckets', 'describe_instances')
        params: JSON string of parameters (optional)
    """
    if DEMO_MODE:
        logger.info(f"[DEMO] call_boto3: {service}.{operation}({params})")
        result = _demo_boto3(service, operation, params)
        return f"[SIMULATED] boto3.client('{service}').{operation}({params})\n\n{result}"

    # Validate params JSON before spawning subprocess
    try:
        json.loads(params) if params and params != "{}" else {}
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON params: {e}"

    script = f"""
import boto3, os, json

region = os.getenv("AWS_REGION", "us-west-2")
role_arn = os.getenv("AWS_ASSUME_ROLE_ARN", "")

# If cross-account role is configured, assume it first
if role_arn:
    sts = boto3.client("sts", region_name=region)
    creds = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName=os.getenv("AWS_ASSUME_ROLE_SESSION_NAME", "agent-scan"),
    )["Credentials"]
    session = boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
        region_name=region,
    )
    client = session.client({service!r})
else:
    client = boto3.client({service!r}, region_name=region)

kwargs = json.loads({params!r}) if {params!r} and {params!r} != "{{}}" else {{}}
method = getattr(client, {operation!r})
response = method(**kwargs)
response.pop("ResponseMetadata", None)
print(json.dumps(response, default=str, indent=2)[:10000])
"""
    return _run_boto3_script(script)


@tool
def get_steering(name: str) -> str:
    """Load a steering workflow by name. Use this to get detailed step-by-step instructions for a specific task.

    Args:
        name: Name of the steering file (e.g. 'wa-security-workflow', 'cost-optimization-scan')
    """
    logger.info(f"[STEERING] Loading: {name}")
    content = load_steering_file(name)
    logger.info(f"[STEERING] Loaded {name}: {len(content)} chars")
    return content


def create_supervisor_agent():
    """Create the top-level supervisor agent."""
    model_id = get_model_id()
    bedrock_model = BedrockModel(
        model_id=model_id,
        region_name=os.getenv("AWS_REGION", "us-west-2"),
    )

    # Build steering index for the system prompt
    steering_index = list_steering_files()
    if steering_index:
        index_lines = "\n".join(f"  - {name}: {desc}" for name, desc in steering_index.items())
        steering_section = f"""
Available steering workflows (use get_steering tool to load before executing):
{index_lines}

IMPORTANT: When a user request matches a steering workflow, you MUST call get_steering with the workflow name
to load the full procedure, then follow it exactly. Do NOT attempt the task from memory."""
    else:
        steering_section = ""

    demo_note = ""
    if DEMO_MODE:
        demo_note = """

DEMO MODE ACTIVE: All AWS API calls return simulated data. Each response is prefixed with [SIMULATED].
Present findings as if they are real. The demo account has: 3 EC2 instances, 4 S3 buckets, 1 Aurora MySQL cluster,
GuardDuty enabled with 2 findings, CloudTrail active, some security issues (SSH open to world, unencrypted EBS volume, 1 user without MFA)."""

    base_prompt = f"""You are an AWS Operations Assistant. You help users query and inspect AWS resources.

Current date: {__import__('datetime').datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}{demo_note}

Available tools:
- call_aws: Execute AWS CLI commands (e.g. 'aws s3 ls', 'aws ec2 describe-instances')
- call_boto3: Execute boto3 API calls directly (service, operation, params)
- get_steering: Load a detailed workflow procedure by name
- think: Plan complex operations before executing

Always use call_boto3 for simple operations. Use call_aws for complex CLI commands with specific flags.
Be concise in responses. Show the key information users need.{steering_section}"""

    return Agent(
        model=bedrock_model,
        system_prompt=base_prompt,
        tools=[call_aws, call_boto3, get_steering, think],
    )
