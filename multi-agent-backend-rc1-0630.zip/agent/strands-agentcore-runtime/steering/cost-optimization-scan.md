# AWS Cost Optimization Quick Scan

**Mode**: Fully autonomous — zero human interaction after invocation.
**Scope**: Cost optimization across all AWS services.
**Output**: Markdown summary with spend trends, savings opportunities, and quick wins.

---

## DEMO MODE

If DEMO_MODE is active (you will see `[SIMULATED]` prefixes on API responses), **skip all individual API calls** and immediately return the following pre-built report. Do NOT call any tools — just output this report directly:

```markdown
# 💰 AWS Cost Optimization Scan (Demo)

**Account**: 123456789012 | **Region**: us-west-2 | **Date**: 2026-06-19
**Mode**: DEMO — Simulated scan with representative data

---

## Scan Flow & Commands Executed

In a live run, the following AWS CLI/API calls would be executed:

```
$ aws ce get-cost-and-usage --time-period Start=2026-01-01,End=2026-06-18 --granularity MONTHLY --metrics UnblendedCost
$ aws ce get-cost-and-usage --group-by Type=DIMENSION,Key=SERVICE (service breakdown)
$ aws ce get-cost-forecast --time-period Start=2026-06-18,End=2026-09-18 --metric UNBLENDED_COST
$ aws cost-optimization-hub list-recommendation-summaries --group-by RecommendationType
$ aws compute-optimizer get-recommendation-summaries
$ aws ce get-savings-plans-utilization
$ aws ce get-reservation-utilization
$ aws ce get-anomalies --date-interval (last 90 days)
$ aws ec2 describe-volumes --filters Name=status,Values=available (orphaned EBS)
$ aws ec2 describe-addresses --query 'Addresses[?AssociationId==null]' (unused EIPs)
```

---

## Monthly Spend Trend

| Month | Cost | MoM Change |
|-------|------|------------|
| Jan 2026 | $4,523 | — |
| Feb 2026 | $4,891 | +8.1% |
| Mar 2026 | $5,103 | +4.3% |
| Apr 2026 | $5,467 | +7.1% |
| May 2026 | $5,790 | +5.9% |
| Jun 2026 (MTD) | $3,421 | — |

> ⚠️ **Spend trending up +28% over 5 months**

**Run Rate**: ~$5,790/mo | **Forecast (Jul–Sep)**: $6,150 → $6,320 → $6,480

---

## Savings Opportunities

| Source | Finding | Est. Monthly Savings |
|--------|---------|---------------------|
| Compute Optimizer | 2 over-provisioned EC2 instances | ~$200–$400 |
| Compute Optimizer | 1 under-optimized EBS volume | ~$20–$50 |
| Orphaned Resources | vol-0ccc3333 (20GB gp2, unattached) | ~$2 |
| Savings Plans | No commitment — full on-demand rates | ~$1,000–$1,200 |

**Total Estimated Savings: ~$1,200–$1,650/mo**

---

## Quick Wins

1. **Purchase Compute Savings Plan** — 1-year commitment saves 20–40% on EC2/Fargate (~$1,000/mo)
2. **Rightsize 2 EC2 instances** — Compute Optimizer flagged over-provisioned (~$300/mo)
3. **Delete orphaned EBS vol-0ccc3333** — Unattached, unencrypted, costs ~$2/mo but is a security risk

---

## Data Collection Status

| Source | Status |
|--------|--------|
| Cost Explorer (Monthly) | ✅ |
| Cost Explorer (Service) | ✅ |
| Cost Forecast | ✅ |
| Compute Optimizer | ✅ 3 findings |
| Orphaned EBS | ✅ 1 found |
| Unused EIPs | ✅ None |
| Cost Anomalies | ✅ None detected |
| Savings Plans | ⚠️ Not active |
| Reserved Instances | ⚠️ Not active |
| Cost Optimization Hub | ❌ Not enabled |
```

*Simulated data — in production, all figures reflect actual account spend.*

**END OF DEMO REPORT** — Output the above report directly. Do not call any tools.

---

## Execution Flow

### Step 1: Bootstrap

```bash
aws sts get-caller-identity
```

Log account ID and region. Proceed immediately.

### Step 2: Collect Cost Data

Run ALL of these. If any call fails (permissions, service not enabled), note it and continue.

#### Monthly Spend (last 6 months)
```bash
aws ce get-cost-and-usage --time-period Start=$(date -v-6m +%Y-%m-01),End=$(date +%Y-%m-01) --granularity MONTHLY --metrics "UnblendedCost"
```

#### Spend by Service (last 30 days)
```bash
aws ce get-cost-and-usage --time-period Start=$(date -v-1m +%Y-%m-%d),End=$(date +%Y-%m-%d) --granularity MONTHLY --metrics "UnblendedCost" --group-by Type=DIMENSION,Key=SERVICE
```

#### Cost Forecast (next 3 months)
```bash
aws ce get-cost-forecast --time-period Start=$(date +%Y-%m-%d),End=$(date -v+3m +%Y-%m-%d) --granularity MONTHLY --metric UNBLENDED_COST
```

#### Cost Optimization Hub Recommendations
```bash
aws cost-optimization-hub list-recommendation-summaries --group-by RecommendationType
```

#### Compute Optimizer (EC2 rightsizing)
```bash
aws compute-optimizer get-recommendation-summaries
```

#### Savings Plans Utilization
```bash
aws ce get-savings-plans-utilization --time-period Start=$(date -v-1m +%Y-%m-01),End=$(date +%Y-%m-01)
```

#### Reservation Utilization
```bash
aws ce get-reservation-utilization --time-period Start=$(date -v-1m +%Y-%m-01),End=$(date +%Y-%m-01)
```

#### Cost Anomalies (last 90 days)
```bash
aws ce get-anomalies --date-interval StartDate=$(date -v-90d +%Y-%m-%d),EndDate=$(date +%Y-%m-%d) --max-results 10
```

#### Orphaned Resources
```bash
# Unattached EBS volumes
aws ec2 describe-volumes --filters Name=status,Values=available --query 'Volumes[].{ID:VolumeId,Size:Size,Type:VolumeType}'

# Unassociated Elastic IPs
aws ec2 describe-addresses --query 'Addresses[?AssociationId==null].{IP:PublicIp,AllocationId:AllocationId}'
```

### Step 3: Produce Summary

Output a concise summary:

```markdown
## 💰 AWS Cost Scan Summary

**Account**: {account-id} | **Region**: {region} | **Scan Date**: {date}

### Monthly Spend Trend
| Month | Cost |
|-------|------|
| ... | $X,XXX |

**Current Monthly Run Rate**: $X,XXX
**3-Month Forecast**: $X,XXX

### Top 5 Services by Cost (Last 30 Days)
| Service | Cost | % of Total |
|---------|------|------------|
| ... | $XXX | XX% |

### Savings Opportunities Found
| Source | Count | Est. Monthly Savings |
|--------|-------|---------------------|
| Cost Optimization Hub | X | $XXX |
| Compute Optimizer | X | $XXX |
| Orphaned Resources | X | $XXX |

**Total Estimated Monthly Savings**: $X,XXX

### Quick Wins (Immediate Actions)
1. {action} — saves ~$XXX/mo
2. {action} — saves ~$XXX/mo
3. {action} — saves ~$XXX/mo

### Data Collection Status
| Service | Status |
|---------|--------|
| Cost Explorer | ✅/❌ |
| Compute Optimizer | ✅/❌ |
| Cost Optimization Hub | ✅/❌ |
```

---

## Execution Rules

1. **Zero interaction**: No prompts, no confirmations.
2. **Fail-forward**: Skip failed checks, don't stop the workflow.
3. **Concise**: One-page summary, not a full report.
4. **Actionable**: Top 3 quick wins with dollar estimates.
5. **Transparent**: Shows which data sources succeeded or failed.
6. **Read-only**: No modifications to any resources.
