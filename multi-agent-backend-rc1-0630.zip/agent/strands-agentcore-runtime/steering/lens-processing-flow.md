---
inclusion: manual
---

# Lens Processing Flow

This steering file defines the end-to-end flow for processing an AWS Well-Architected custom lens document into validated, actionable check files. It orchestrates three stages: Lens Processing, Best Practice Material Processing, and Check File Validation.

## Input Configuration

The flow requires two inputs: the path to the source lens document and the output directory for generated checks.

**Lens Source Document**: `#[[file:REPLACE_WITH_LENS_FILE_PATH]]`

**Output Directory**: `REPLACE_WITH_OUTPUT_DIRECTORY`

> **Usage**: 
> - Replace `REPLACE_WITH_LENS_FILE_PATH` with the relative path to your lens JSON file or best practice material file (markdown/PDF/plaintext) before activating this steering file.
> - Replace `REPLACE_WITH_OUTPUT_DIRECTORY` with the relative path where generated check files should be written (e.g., `checks-output/aurora-mysql-lens/`).
>
> **Important**: The output directory MUST be different from the input source directory. This keeps source lens files cleanly separated from generated artifacts.

---

## High-Level Flow

This flow transforms a lens document into a set of validated, machine-readable check files that can be consumed by tools like Service Screener or Tevico.

```
┌─────────────────────────┐
│  INPUT                   │
│  Lens JSON file          │
│  or Best Practice file   │
│  (markdown/PDF/txt)      │
│  Location: lens-src/     │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Stage 1: Process        │
│  - Validate structure    │
│  - Extract questions     │
│    and choices           │
│  - Map AWS services      │
│  - Generate service list │
│    and check files       │
│  - Write to OUTPUT dir   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Stage 2: Validate       │
│  - Verify CLI commands   │
│  - Verify Boto3 methods  │
│  - Cross-check alignment │
│  - Record result inline  │
│    in the .check.md file │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  OUTPUT                  │
│  Single .check.md per    │
│  choice with validation  │
│  status embedded         │
│  Location: checks-output/│
│  (see Expected Output)   │
└─────────────────────────┘
```

---

## Expected Output

Given a lens with **P** pillars, **Q** questions total, and **C** best-practice choices per question (excluding "None of above" choices that end in `_no`):

### Per Question
| File | Purpose |
|------|---------|
| `{question_id}.service_list.md` | Lists AWS services relevant to the question, categorized as primary, supporting, and management services. Includes risk assessment. |

### Per Choice (best practice)
| File | Purpose |
|------|---------|
| `{choice_id}.check.md` | Single output file containing the actionable check plus validation results embedded at the end (if passed) or top (if failed/inconclusive). |

### Example Output Structure

For a lens with 2 pillars (Security, Cost Optimization), 3 questions, and 4 valid choices per question:

```
<workspace-root>/
├── lens-src/                          # INPUT: Source lens files (untouched)
│   └── my-lens/
│       └── MyLens_v1.json
│
├── checks-output/                     # OUTPUT: Generated check files
│   └── my-lens/
│       ├── SEC1.service_list.md
│       ├── SEC1_1.check.md
│       ├── SEC1_2.check.md
│       ├── SEC1_3.check.md
│       ├── SEC1_4.check.md
│       │
│       ├── SEC2.service_list.md
│       ├── SEC2_1.check.md
│       ├── ...
│       │
│       ├── COST1.service_list.md
│       ├── COST1_1.check.md
│       └── ...
```

> **Separation principle**: Source lens documents in `lens-src/` are never modified. All generated artifacts go to the configured output directory (e.g., `checks-output/`).

### File Count Formula

| Output type | Count |
|-------------|-------|
| Service list files | Q (one per question) |
| Check files | C_total (total non-"none" choices across all questions) |
| **Total files** | **Q + C_total** |

### What Each File Contains

**`.service_list.md`** — AWS service mapping for a question:
- Primary services (directly mentioned in question/choices)
- Supporting services (enable or complement primary)
- Management and governance services (monitoring, compliance)
- Related technologies (protocols, standards)
- Risk assessment conditions (no-risk, high-risk, default)

**`.check.md`** — Actionable check for a single best practice, with validation embedded:
- Description of what is being checked
- Helpful resources with reference URLs
- Improvement plan from the lens
- AWS CLI commands to verify compliance
- Boto3 methods for programmatic validation
- Python validation function (returns pass/fail)
- Step-by-step implementation checklist
- Common issues and troubleshooting
- **Validation record** (appended at end if PASSED, or prepended at top if FAILED/INCONCLUSIVE)

---

## Validation Output Format

Every `.check.md` file is validated. The validation result is recorded **inline** in the file itself. No separate `.validated.md` files are created.

### If validation PASSES

Append a `## Validation Record` section at the **end** of the file:

```markdown
---

## Validation Record

**Status**: ✅ VALIDATED  
**Validated On**: {YYYY-MM-DD}

### Checks Performed
- [x] Description keywords match identified AWS services
- [x] AWS CLI commands are syntactically correct and relevant
- [x] Boto3 methods align with CLI commands
- [x] CLI and Boto3 approaches check the same resources
- [x] Both approaches lead to consistent compliance conclusions

### Notes
{Any observations or minor clarifications from validation}
```

### If validation FAILS or is INCONCLUSIVE

Prepend a `> [!WARNING]` block at the **top** of the file (before the title), explaining why:

```markdown
> [!WARNING]
> **Validation Status**: ⚠️ REQUIRES REVIEW  
> **Reason**: {One of the categories below}
>
> **Details**: {Specific explanation of what could not be validated}
>
> **Suggested Action**: {What a human reviewer should check}

---

```

### Failure/Inconclusive Reason Categories

| Reason | When to use |
|--------|-------------|
| `NO_DIRECT_SERVICE_MAPPING` | The best practice is organizational, procedural, or governance-oriented and does not map to a single AWS service API call. Example: "Establish a cloud center of excellence" or "Define tagging standards." |
| `MULTI_SERVICE_COMBINATION` | The check requires coordinating multiple services together and cannot be validated by a single CLI/Boto3 call. Example: "Implement end-to-end encryption" spanning KMS + S3 + RDS + ELB. |
| `REQUIRES_BUSINESS_CONTEXT` | The best practice depends on customer-specific business logic, naming conventions, organizational structure, or cost thresholds that cannot be generalized. Example: "Ensure workloads align with business criticality tiers." |
| `CLI_SYNTAX_INVALID` | The generated CLI commands have syntactic errors or reference non-existent subcommands/parameters. |
| `BOTO3_METHOD_MISMATCH` | Boto3 methods don't exist, use wrong parameters, or check different resources than the CLI commands. |
| `CLI_BOTO3_INCONSISTENCY` | CLI and Boto3 sections target different resources or would produce contradictory conclusions. |

### Example: Inconclusive check (top of file)

```markdown
> [!WARNING]
> **Validation Status**: ⚠️ REQUIRES REVIEW  
> **Reason**: MULTI_SERVICE_COMBINATION
>
> **Details**: This best practice ("Implement defense-in-depth network security") requires 
> checking Security Groups (EC2), Network ACLs (VPC), WAF rules, Shield Advanced, and 
> GuardDuty findings in combination. No single CLI command validates the full practice.
>
> **Suggested Action**: Review each service check independently. Consider splitting into 
> sub-checks per service layer, or implement a composite validation script.

---

# SEC3_2 Check - Implement Defense-in-Depth Network Security
...
```

### Example: Passed check (end of file)

```markdown
...
## Common Issues and Troubleshooting

- Issue: Flow logs not appearing → Check IAM permissions for the flow log role
- Issue: Incomplete data → Verify log format includes all required fields

---

## Validation Record

**Status**: ✅ VALIDATED  
**Validated On**: 2025-06-17

### Checks Performed
- [x] Description keywords match identified AWS services
- [x] AWS CLI commands are syntactically correct and relevant
- [x] Boto3 methods align with CLI commands
- [x] CLI and Boto3 approaches check the same resources
- [x] Both approaches lead to consistent compliance conclusions

### Notes
CLI uses `describe-flow-logs` with VPC filter; Boto3 uses equivalent `describe_flow_logs()` with matching parameters. Both confirm VPC Flow Logs are enabled and configured correctly.
```

---

## Stage 1: Process Source Document

Determine the source type and process accordingly.

### If source is a Lens JSON file:

1. **Validate the lens structure** against the [AWS Well-Architected Lens Format Specification](https://docs.aws.amazon.com/wellarchitected/latest/userguide/lenses-format-specification.html):
   - Required schema elements: `schemaVersion`, `name`, `description`, `owner`, `version`
   - Valid pillars, questions, choices, helpfulResource, improvementPlan

2. **Create Service List files** for each question:
   - Extract all questions from the lens file
   - For each question, analyze choices to identify relevant AWS services
   - Use the AWS service knowledge base from `aws-services/*.md` for keyword mapping
   - Create `{question_id}.service_list.md` following the template at `template/question.service_list.md`
   - Include content from reference URLs using fetch MCP when available

3. **Create Check Item files** for each choice:
   - For each choice representing a best practice, create `{choice_id}.check.md`
   - Skip choices with `_no` postfix (they represent "None of above" options)
   - Follow the template at `template/bp.check.md`
   - Include relevant AWS CLI commands and boto3 methods
   - Focus on service features and configuration APIs supporting the best practice

4. **File placement**: All generated files go in the configured **Output Directory**. Create the directory if it does not exist. The source lens file directory is never modified.

   Example: If the input is `lens-src/aurora-mysql-lens/AuroraMySQL_CustomLens_v1.json` and the output directory is `checks-output/aurora-mysql-lens/`, all `.service_list.md` and `.check.md` files are written to `checks-output/aurora-mysql-lens/`.

### If source is a Best Practice Material file (markdown/PDF/plaintext):

1. **Validate AWS Relevance**: Confirm the file contains AWS-related best practices, security guidelines, or operational recommendations.

2. **Parse Content**: Extract all distinct best practice items. Each item should be a single actionable recommendation.

3. **For each best practice item**:
   - **Generate Service List**: Create `{item_id}.service_list.md` following `template/question.service_list.md`
   - **Create Check File**: Generate `{item_id}.check.md` following `template/bp.check.md`

4. **File Organization**: Place generated files in the configured **Output Directory**, under a subdirectory named after the source material. Create the directory if it does not exist. The source material directory is never modified.

5. **Naming Convention**: Use descriptive, lowercase, underscore-separated IDs (e.g., `secure_root_account.service_list.md`, `enable_mfa.check.md`).

6. **Summary Report**: Create a summary markdown listing total items, files generated, services identified, and any warnings.

---

## Stage 2: Validate Check Files

After all `.check.md` files are generated, validate each one. Every check file goes through validation — no exceptions.

1. **Description Analysis**:
   - Review the "Description" section to understand what the check validates
   - Scan keywords against `aws-services/*.md` to confirm correct AWS service linkage
   - If keywords in the question/choice indicate a specific AWS service, verify it's referenced

2. **AWS CLI Command Validation**:
   - Verify CLI commands would produce output relevant to the Description
   - Check syntactic correctness and correct service/resource targeting
   - Ensure commands are executable and use valid parameters

3. **Boto3 Methods Alignment**:
   - Ensure Boto3 method calls align with and complement CLI command outputs
   - Verify both approaches yield consistent information about the same resources

4. **Consistency Check**:
   - Confirm CLI commands and Boto methods check the same underlying resources
   - Identify and fix discrepancies between CLI and Boto approaches
   - Ensure both lead to the same compliance conclusions

5. **Record validation result inline**:
   - **If all checks pass**: Append `## Validation Record` section at the **end** of the `.check.md` file with ✅ VALIDATED status and checklist
   - **If validation fails or is inconclusive**: Prepend a `> [!WARNING]` block at the **top** of the `.check.md` file with the appropriate reason category:
     - `NO_DIRECT_SERVICE_MAPPING` — best practice is procedural/organizational with no direct API mapping
     - `MULTI_SERVICE_COMBINATION` — requires coordinating multiple services; no single check validates it
     - `REQUIRES_BUSINESS_CONTEXT` — depends on customer-specific logic, naming, org structure, or thresholds
     - `CLI_SYNTAX_INVALID` — CLI commands have errors
     - `BOTO3_METHOD_MISMATCH` — Boto3 methods are incorrect or misaligned
     - `CLI_BOTO3_INCONSISTENCY` — CLI and Boto3 target different resources

   **Do NOT create separate `.validated.md` files.** The single `.check.md` is the final output.

---

## AWS Service Knowledge Base

Use the local knowledge base at `aws-services/*.md` for service identification throughout the flow. Each service file contains:
- Service description and capabilities
- Keyword mappings (primary, technical, use case, integration, management)

Reference: `#[[file:aws-services/README.md]]`

---

## Templates

The flow uses two templates for output generation:

- **Service List Template**: `#[[file:template/question.service_list.md]]`
- **Check File Template**: `#[[file:template/bp.check.md]]`

---

## Execution Instructions

1. Set the lens source document path in the Input Configuration section above
2. Set the output directory path in the Input Configuration section above
3. Verify that the output directory is different from the source directory
4. Execute Stage 1 completely before proceeding to Stage 2
5. Stage 2 should process each `.check.md` file in the output directory sequentially
6. Report progress after each stage completes
7. For each check file, record the validation result directly in the file (end for pass, top for fail/inconclusive)

---

## Adapting This Flow for Other Workspaces

To use this flow in another workspace:

1. Copy this file to `.kiro/steering/` in the target workspace
2. Copy the `template/` directory (containing `question.service_list.md` and `bp.check.md`)
3. Copy the `aws-services/` knowledge base directory
4. Update the `REPLACE_WITH_LENS_FILE_PATH` placeholder with your actual lens document path
5. Update the `REPLACE_WITH_OUTPUT_DIRECTORY` placeholder with your desired output path
6. Ensure the output directory does not overlap with the source directory
7. Optionally set up the corresponding hooks for automated triggering:
   - `aws-lens-processor` hook for `.json` lens files
   - `best-practice-processor` hook for markdown/PDF best practice materials
   - `check-file-validator` hook for generated `.check.md` files (records validation inline)
