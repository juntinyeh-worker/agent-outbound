---
inclusion: manual
---

# Create Inline Checks

Generate AWS CLI commands and Boto3 validation logic directly in chat from a plain-language requirement — no lens JSON or file scaffolding needed.

## Purpose

Quickly prototype a compliance/governance check by describing what you want to validate in natural language. The output stays inline in chat (not written to files) unless you explicitly ask to persist it.

## When to Use

- You have a single best-practice requirement and want to see the AWS CLI + Boto3 approach immediately
- You're exploring whether a requirement is programmatically verifiable before committing to a full `.check.md`
- You want a quick reference for a buildspec, pipeline step, or audit script

## Workflow

1. **User provides a requirement** — one or more sentences describing the desired AWS configuration, behavior, or enforcement rule.
2. **Agent responds with**:
   - A concise restatement of the requirement
   - AWS CLI commands to verify or enforce compliance
   - Boto3 validation function (returns `True`/`False`)
   - Key distinctions or gotchas (if any)
3. **Optionally** the user can ask to:
   - Persist the output as a `.check.md` file (follows `template/bp.check.md` format)
   - Add a service list (follows `template/question.service_list.md` format)
   - Expand with implementation checklist and troubleshooting

## Output Format

When generating inline checks, follow this structure:

```
## Requirement
> {Restated requirement in one clear sentence}

## AWS CLI Commands
{Bash code block with commented CLI commands}

## Boto3 Validation Logic
{Python code block with:
  - A function that performs the check (returns bool or dict)
  - A validation function that prints pass/fail status
  - Clear docstrings explaining what is being validated}

## Key Distinctions (if applicable)
{Table or bullets explaining common misunderstandings or edge cases}
```

## Guidelines for Generating Checks

### CLI Commands
- Include commands to **inspect current state** (read-only first)
- Include commands to **enforce/remediate** (clearly labeled)
- Use realistic placeholder values (e.g., `my-cluster`, `my-service`)
- Add inline comments explaining each command's purpose
- Group logically (verify → enforce → validate)

### Boto3 Logic
- Import only required clients
- Handle errors with try/except
- Return structured results (not just print)
- Include a `validate_*` function that returns `bool` for automation
- Use descriptive function names matching the requirement

### Service Identification
- Reference `aws-services/*.md` knowledge base for keyword mapping
- Call out which AWS services are involved
- Note if the check spans multiple services (may affect automateability)

### Validation Feasibility
- If the requirement is purely organizational/procedural, state that upfront
- If it requires business context (naming conventions, thresholds), note what the user needs to supply
- If it's a multi-service combination, explain which parts can be automated independently

## Persisting to File

If the user asks to save the check, write it to the configured output directory following the `template/bp.check.md` template format:

- **File naming**: `{descriptive_snake_case_id}.check.md`
- **Output location**: User-specified or default `checks-output/inline-checks/`
- **Include validation record**: Run Stage 2 validation logic from `lens-processing-flow.md` and embed result inline

## Examples

### Example user input:
> "Make sure all S3 buckets have versioning enabled"

### Example user input:
> "ECS services must register a new task definition revision on every deploy to force fresh image pulls for mutable tags"

### Example user input:
> "Lambda functions should not use the default execution timeout of 3 seconds"

---

## Relationship to Other Steering Files

- **`lens-processing-flow.md`**: Full pipeline for processing lens JSON or best-practice material files into check artifacts. Use that for batch processing.
- **This file (`create-inline-checks.md`)**: Lightweight, conversational check generation. Use this for one-off exploration and rapid prototyping.
- Both produce the same `.check.md` format when persisted.
