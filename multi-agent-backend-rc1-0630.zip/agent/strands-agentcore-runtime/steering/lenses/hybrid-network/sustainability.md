# Hybrid Networking Lens - Sustainability Skill

## Overview

**Pillar:** Sustainability (SUS)  
**Lens:** Hybrid Networking Lens  
**Questions Covered:** 1  
**Total Checks:** 4  
**All Validated (Automation-Ready):** ✅ Yes (95%+ service linkable)  
**Generated On:** 2026-06-18

This skill aggregates all Sustainability checks for the Hybrid Networking Lens into a single reference for pillar-level assessment and automation.

---

## Questions Summary

| Question | Title | Checks |
|----------|-------|--------|
| SUS1 | How do you apply general sustainability principles to your h | 4 |

---

## Checks Index


### SUS1: How do you apply general sustainability principles to your hybrid networking architecture

| Check | Title | File |
|-------|-------|------|
| SUS1_1 | Right-size hybrid networking resources | `SUS1_1.check.md` |
| SUS1_2 | Maximize utilization of provisioned resources | `SUS1_2.check.md` |
| SUS1_3 | Minimize total resources required | `SUS1_3.check.md` |
| SUS1_4 | Leverage AWS managed services for efficiency | `SUS1_4.check.md` |

---

## Composite Validation Script

Run all Sustainability checks for this lens:

```python
#!/usr/bin/env python3
"""
Hybrid Networking Lens - Sustainability Pillar Validation
Runs all checks and reports compliance status.
"""
import importlib.util
import os
import sys

def run_all_sus_checks():
    checks_dir = os.path.dirname(os.path.abspath(__file__))
    results = {}
    
    check_files = [
        'SUS1_1.check.md',
        'SUS1_2.check.md',
        'SUS1_3.check.md',
        'SUS1_4.check.md',
    ]
    
    # Summary
    total = 4
    print(f"\n{'='*60}")
    print(f"SUSTAINABILITY PILLAR - Hybrid Networking Lens")
    print(f"{'='*60}")
    print(f"  Total checks: {total}")
    print(f"  All checks have inline validation logic in their .check.md files")
    print(f"  Run individual validate_implementation() functions per check")
    
    return results

if __name__ == '__main__':
    run_all_sus_checks()
```

---

## Key AWS Services

- Amazon EC2
- AWS Direct Connect
- AWS Site-to-Site VPN
