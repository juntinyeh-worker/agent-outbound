# Aurora MySQL - Performance Efficiency Skill

## Overview

**Pillar:** Performance Efficiency (pillar_id_1)  
**Lens:** Aurora MySQL Custom Lens  
**Questions Covered:** 8 (Q1–Q8)  
**Total Checks:** 30  
**Validated (Automation-Ready):** 14  
**Requires Review (Manual):** 16  

This skill aggregates all Performance Efficiency checks for Aurora MySQL into a single reference. Validated checks can be run programmatically via their `validate_implementation()` functions. Checks requiring review need manual database-level inspection or business context.

---

## Questions Summary

| Question | Title | Choices | Validated | Review |
|----------|-------|---------|-----------|--------|
| Q1 | Do your query patterns meet best practices? | 7 | 3 | 4 |
| Q2 | How do you scale for writes? | 6 | 2 | 4 |
| Q3 | How do you scale for reads? | 7 | 2+ | varies |
| Q4 | How do you optimize for concurrency? | 5 | 4 | 1 |
| Q5 | How do you size your cluster? | 3 | 1 | 2 |
| Q6 | How do you monitor performance? | 7 | varies | varies |
| Q7 | How does your application connect? | 3 | 0 | 3 |
| Q8 | Do you run analytical queries? | 3 | varies | varies |

---

## Validated Checks (Automation-Ready)

These checks have passed validation and can be executed programmatically against an AWS account.

### Q1: Do your query patterns meet best practices?

#### q1_choice3: Have baseline expected performance metrics for top queries ✅

```python
def validate_q1_choice3():
    """Validate Performance Insights is enabled with adequate retention for baselining."""
    import boto3
    rds_client = boto3.client('rds')
    
    clusters = rds_client.describe_db_clusters()['DBClusters']
    aurora_clusters = [c for c in clusters if c['Engine'] == 'aurora-mysql']
    
    if not aurora_clusters:
        return False
    
    all_ok = True
    for cluster in aurora_clusters:
        cluster_id = cluster['DBClusterIdentifier']
        instances = rds_client.describe_db_instances(
            Filters=[{'Name': 'db-cluster-id', 'Values': [cluster_id]}]
        )['DBInstances']
        
        for inst in instances:
            pi_enabled = inst.get('PerformanceInsightsEnabled', False)
            pi_retention = inst.get('PerformanceInsightsRetentionPeriod', 0)
            if not pi_enabled:
                all_ok = False
            elif pi_retention < 7:
                all_ok = False
    return all_ok
```

**Pass criteria:** All instances have Performance Insights enabled with ≥7 day retention.

---

#### q1_choice4: Have a defined process to monitor & validate current performance ✅

```python
def validate_q1_choice4():
    """Validate monitoring infrastructure (Enhanced Monitoring, PI, CloudWatch alarms)."""
    import boto3
    rds_client = boto3.client('rds')
    cw_client = boto3.client('cloudwatch')
    
    clusters = rds_client.describe_db_clusters()['DBClusters']
    aurora_clusters = [c for c in clusters if c['Engine'] == 'aurora-mysql']
    
    if not aurora_clusters:
        return False
    
    all_ok = True
    for cluster in aurora_clusters:
        cluster_id = cluster['DBClusterIdentifier']
        instances = rds_client.describe_db_instances(
            Filters=[{'Name': 'db-cluster-id', 'Values': [cluster_id]}]
        )['DBInstances']
        
        for inst in instances:
            em_interval = inst.get('MonitoringInterval', 0)
            pi_enabled = inst.get('PerformanceInsightsEnabled', False)
            if em_interval == 0 and not pi_enabled:
                all_ok = False
        
        alarms = cw_client.describe_alarms()['MetricAlarms']
        perf_alarms = [a for a in alarms 
                      if a.get('Namespace') == 'AWS/RDS'
                      and a['MetricName'] in ('CPUUtilization', 'ReadLatency', 'WriteLatency')]
        if len(perf_alarms) == 0:
            all_ok = False
    return all_ok
```

**Pass criteria:** All instances have Enhanced Monitoring OR Performance Insights enabled, plus at least one performance alarm exists.

---

### Q2: How do you scale for writes?

#### q2_choice2: Turn off bin logs if no use case ✅

```python
def validate_q2_choice2():
    """Validate binlog is disabled when no replication/CDC exists."""
    import boto3
    rds_client = boto3.client('rds')
    
    clusters = rds_client.describe_db_clusters()['DBClusters']
    aurora_clusters = [c for c in clusters if c['Engine'] == 'aurora-mysql']
    
    if not aurora_clusters:
        return False
    
    all_ok = True
    for cluster in aurora_clusters:
        param_group = cluster['DBClusterParameterGroup']
        repl_source = cluster.get('ReplicationSourceIdentifier', '')
        
        paginator = rds_client.get_paginator('describe_db_cluster_parameters')
        binlog_format = 'OFF'
        for page in paginator.paginate(DBClusterParameterGroupName=param_group):
            for param in page['Parameters']:
                if param['ParameterName'] == 'binlog_format':
                    binlog_format = param.get('ParameterValue') or 'OFF'
                    break
        
        if binlog_format not in ('OFF', ''):
            if not repl_source:
                all_ok = False
    return all_ok
```

**Pass criteria:** binlog_format=OFF unless replication is active.

---

#### q2_choice4: Implement Serverless configuration for variable workloads ✅

```python
def validate_q2_choice4():
    """Validate Aurora Serverless v2 is configured."""
    import boto3
    rds_client = boto3.client('rds')
    
    clusters = rds_client.describe_db_clusters()['DBClusters']
    aurora_clusters = [c for c in clusters if c['Engine'] == 'aurora-mysql']
    
    if not aurora_clusters:
        return False
    
    for cluster in aurora_clusters:
        sv2_config = cluster.get('ServerlessV2ScalingConfiguration', {})
        if sv2_config:
            return True
        instances = rds_client.describe_db_instances(
            Filters=[{'Name': 'db-cluster-id', 'Values': [cluster['DBClusterIdentifier']]}]
        )['DBInstances']
        if any('serverless' in i.get('DBInstanceClass', '') for i in instances):
            return True
    return False
```

**Pass criteria:** At least one cluster has ServerlessV2ScalingConfiguration or serverless instances.

---

### Q4: How do you optimize for concurrency?

#### q4_choice5: Leverage RDS Proxy for multiplexing ✅

```python
def validate_q4_choice5():
    """Validate RDS Proxy exists with MYSQL engine family."""
    import boto3
    rds_client = boto3.client('rds')
    
    proxies = rds_client.describe_db_proxies()['DBProxies']
    mysql_proxies = [p for p in proxies if p.get('EngineFamily') == 'MYSQL']
    
    if not mysql_proxies:
        return False
    
    return all(p['Status'] == 'available' for p in mysql_proxies)
```

**Pass criteria:** At least one MYSQL RDS Proxy exists in "available" status.

---

## Checks Requiring Review (Manual Validation)

These checks cannot be fully automated via AWS APIs — they require database-level queries, application code review, or business context.

### Q1: Do your query patterns meet best practices?

| Check | Title | Reason |
|-------|-------|--------|
| q1_choice1 | Confirm workload/query pattern is a fit for Aurora | REQUIRES_BUSINESS_CONTEXT |
| q1_choice2 | Optimize access patterns for compute resources | REQUIRES_BUSINESS_CONTEXT |
| q1_choice5 | Optimize based on data model | REQUIRES_BUSINESS_CONTEXT |
| q1_choice6 | Use indexes in fields with high cardinality | REQUIRES_BUSINESS_CONTEXT |
| q1_choice7 | Leverage Primary Key (PK) for all tables | REQUIRES_BUSINESS_CONTEXT |

**Manual validation queries:**
```sql
-- Tables without primary keys
SELECT t.TABLE_SCHEMA, t.TABLE_NAME
FROM information_schema.TABLES t
LEFT JOIN information_schema.TABLE_CONSTRAINTS c
  ON t.TABLE_SCHEMA = c.TABLE_SCHEMA AND t.TABLE_NAME = c.TABLE_NAME
  AND c.CONSTRAINT_TYPE = 'PRIMARY KEY'
WHERE c.CONSTRAINT_NAME IS NULL
  AND t.TABLE_SCHEMA NOT IN ('mysql','information_schema','performance_schema','sys')
  AND t.TABLE_TYPE = 'BASE TABLE';

-- Low-cardinality indexes
SELECT s.TABLE_NAME, s.INDEX_NAME, s.COLUMN_NAME, s.CARDINALITY,
       t.TABLE_ROWS, ROUND(s.CARDINALITY / NULLIF(t.TABLE_ROWS,0)*100, 2) AS selectivity_pct
FROM information_schema.STATISTICS s
JOIN information_schema.TABLES t ON s.TABLE_SCHEMA = t.TABLE_SCHEMA AND s.TABLE_NAME = t.TABLE_NAME
WHERE s.TABLE_SCHEMA NOT IN ('mysql','information_schema','performance_schema','sys')
  AND t.TABLE_ROWS > 1000
ORDER BY selectivity_pct ASC LIMIT 50;
```

---

### Q2: How do you scale for writes?

| Check | Title | Reason |
|-------|-------|--------|
| q2_choice1 | Remove unused or duplicative indexes | REQUIRES_BUSINESS_CONTEXT |
| q2_choice3 | Leverage application-level write distribution (shards) | REQUIRES_BUSINESS_CONTEXT |
| q2_choice5 | Use indexes to tune SQL queries access pattern | REQUIRES_BUSINESS_CONTEXT |
| q2_choice6 | Use table partitions for purging data | REQUIRES_BUSINESS_CONTEXT |

**Manual validation queries:**
```sql
-- Unused indexes
SELECT * FROM sys.schema_unused_indexes
WHERE object_schema NOT IN ('mysql', 'sys', 'performance_schema');

-- Redundant indexes
SELECT * FROM sys.schema_redundant_indexes
WHERE table_schema NOT IN ('mysql', 'sys', 'performance_schema');

-- Table partitions
SELECT TABLE_SCHEMA, TABLE_NAME, PARTITION_NAME, TABLE_ROWS
FROM information_schema.PARTITIONS
WHERE PARTITION_NAME IS NOT NULL
  AND TABLE_SCHEMA NOT IN ('mysql','information_schema','performance_schema','sys');
```

---

### Q3: How do you scale for reads?

| Check | Title | Reason |
|-------|-------|--------|
| q3_choice1 | Configure application logic for read-write splitting | REQUIRES_BUSINESS_CONTEXT |

---

### Q5: How do you size your cluster?

| Check | Title | Reason |
|-------|-------|--------|
| q5_choice1 | Load test for instance sizing | NO_DIRECT_SERVICE_MAPPING |

---

### Q7: How does your application connect?

| Check | Title | Reason |
|-------|-------|--------|
| q7_choice1 | Connect to writer via cluster endpoint | REQUIRES_BUSINESS_CONTEXT |
| q7_choice2 | Connect to reader via reader endpoint | REQUIRES_BUSINESS_CONTEXT |
| q7_choice3 | Use custom endpoints for workload isolation | REQUIRES_BUSINESS_CONTEXT |

---

## Composite Validation Script

Run all validated Performance Efficiency checks in sequence:

```python
#!/usr/bin/env python3
"""
Aurora MySQL - Performance Efficiency Pillar Validation
Runs all automation-ready checks and reports compliance status.
"""
import boto3
from datetime import datetime, timedelta

def run_all_performance_checks():
    results = {}
    
    # Q1: Baseline metrics (Performance Insights)
    results['q1_choice3_baseline_metrics'] = validate_q1_choice3()
    
    # Q1: Monitoring process (Enhanced Monitoring + Alarms)
    results['q1_choice4_monitoring_process'] = validate_q1_choice4()
    
    # Q2: Binary logs disabled
    results['q2_choice2_binlog_disabled'] = validate_q2_choice2()
    
    # Q2: Serverless configuration
    results['q2_choice4_serverless'] = validate_q2_choice4()
    
    # Q4: RDS Proxy multiplexing
    results['q4_choice5_rds_proxy'] = validate_q4_choice5()
    
    # Summary
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    print(f"\n{'='*60}")
    print(f"PERFORMANCE EFFICIENCY PILLAR - VALIDATION SUMMARY")
    print(f"{'='*60}")
    for check, status in results.items():
        icon = '✅' if status else '❌'
        print(f"  {icon} {check}")
    print(f"\n  Result: {passed}/{total} checks passed")
    print(f"  Note: {16 - total} additional checks require manual review")
    
    return results

if __name__ == '__main__':
    run_all_performance_checks()
```

---

## Key AWS Services

- Amazon Aurora MySQL
- Amazon RDS (management APIs)
- Amazon CloudWatch (metrics and alarms)
- AWS Performance Insights
- Amazon RDS Proxy
- AWS KMS (parameter encryption)
- Amazon CloudWatch Alarms
- AWS Application Auto Scaling (read replicas)
