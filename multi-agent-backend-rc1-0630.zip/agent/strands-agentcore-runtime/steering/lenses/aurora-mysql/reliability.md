# Aurora MySQL - Reliability Skill

## Overview

**Pillar:** Reliability (pillar_id_2)  
**Lens:** Aurora MySQL Custom Lens  
**Questions Covered:** 1 (Q1)  
**Total Checks:** 1  
**Validated (Automation-Ready):** 1  
**Requires Review (Manual):** 0  

This skill covers the Reliability pillar checks for Aurora MySQL. Currently only one check is validated (multi-AZ HA), but this is a foundational best practice for production Aurora deployments.

> **Note:** The Reliability pillar has limited coverage in the current lens version. Additional checks for backup/restore, failover testing, and disaster recovery may be added in future iterations.

---

## Questions Summary

| Question | Title | Choices | Validated | Review |
|----------|-------|---------|-----------|--------|
| Q1 | How do you support HA architecture deployments? | 1 | 1 | 0 |

---

## Validated Checks (Automation-Ready)

### Q1: How do you support High Availability (HA) architecture deployments?

#### reliability_q1_choice1: Use minimum of 2 instances across AZs for automatic failover ✅

```python
def validate_reliability_q1_choice1():
    """
    Validate Aurora MySQL clusters have 2+ instances across 2+ AZs.
    This is the minimum requirement for automatic failover and SLA qualification.
    """
    import boto3
    rds_client = boto3.client('rds')
    
    clusters = rds_client.describe_db_clusters()['DBClusters']
    aurora_clusters = [c for c in clusters if c['Engine'] == 'aurora-mysql']
    
    if not aurora_clusters:
        return False
    
    all_compliant = True
    for cluster in aurora_clusters:
        cluster_id = cluster['DBClusterIdentifier']
        
        instances = rds_client.describe_db_instances(
            Filters=[{'Name': 'db-cluster-id', 'Values': [cluster_id]}]
        )['DBInstances']
        
        azs = set(inst['AvailabilityZone'] for inst in instances)
        instance_count = len(instances)
        az_count = len(azs)
        
        if instance_count < 2 or az_count < 2:
            all_compliant = False
    
    return all_compliant
```

**Pass criteria:** Every Aurora MySQL cluster has ≥2 instances distributed across ≥2 Availability Zones.

**Remediation:**
```bash
# Add a reader instance in a different AZ
aws rds create-db-instance \
  --db-cluster-identifier <cluster-id> \
  --db-instance-identifier <cluster-id>-reader \
  --db-instance-class db.r6g.large \
  --engine aurora-mysql \
  --availability-zone <different-az>

# Test failover
aws rds failover-db-cluster \
  --db-cluster-identifier <cluster-id>
```

---

## Checks Requiring Review (Manual Validation)

*None — all Reliability checks are fully automated.*

---

## Composite Validation Script

```python
#!/usr/bin/env python3
"""
Aurora MySQL - Reliability Pillar Validation
Runs all automation-ready reliability checks and reports compliance status.
"""
import boto3

def run_all_reliability_checks():
    results = {}
    
    # Q1: High Availability
    results['q1_choice1_multi_az'] = validate_reliability_q1_choice1()
    
    # Summary
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    print(f"\n{'='*60}")
    print(f"RELIABILITY PILLAR - VALIDATION SUMMARY")
    print(f"{'='*60}")
    for check, status in results.items():
        icon = '✅' if status else '❌'
        print(f"  {icon} {check}")
    print(f"\n  Result: {passed}/{total} checks passed")
    
    return results

if __name__ == '__main__':
    run_all_reliability_checks()
```

---

## Future Expansion Candidates

The Reliability pillar would benefit from additional checks in these areas:

| Candidate Check | AWS API Feasibility | Description |
|-----------------|---------------------|-------------|
| Automated backups enabled | ✅ High | Verify BackupRetentionPeriod > 0 |
| Point-in-time recovery configured | ✅ High | Verify EarliestRestorableTime exists |
| Global Database for DR | ✅ High | Check GlobalClusterIdentifier |
| Deletion protection enabled | ✅ High | Verify DeletionProtection=true |
| Cluster parameter backup window | ✅ High | Verify PreferredBackupWindow is set |
| Failover priority configured | ✅ Medium | Check PromotionTier on instances |
| Blue/Green deployment readiness | ⚠️ Medium | Check engine version supports B/G |

---

## Key AWS Services

- Amazon Aurora MySQL
- Amazon RDS (cluster and instance management)
- Amazon CloudWatch (availability monitoring)
- AWS Backup (centralized backup management)
