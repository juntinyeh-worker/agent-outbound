# Container Build Lens - Operational Excellence Skill

## Overview

**Pillar:** Operational Excellence (operationalExcellence)  
**Lens:** Container Build Lens  
**Questions Covered:** 2  
**Total Checks:** 9  
**All Validated (Automation-Ready):** ✅ Yes (95%+ service linkable)  
**Generated On:** 2026-06-18

This skill aggregates all Operational Excellence checks for the Container Build Lens into a single reference for pillar-level assessment and automation.

---

## Questions Summary

| Question | Title | Checks |
|----------|-------|--------|
| OPS1 | How do you manage the lifecycle of your containers and image | 7 |
| OPS2 | How do you know whether your containerized workload is achie | 2 |

---

## Checks Index


### OPS1: How do you manage the lifecycle of your containers and images?

| Check | Title | File |
|-------|-------|------|
| OPS1_1 | Understand the lineage of your container image | `OPS1_1.check.md` |
| OPS1_2 | Have parity between your deployment environments | `OPS1_2.check.md` |
| OPS1_3 | Build the image once and use the same image in all environme | `OPS1_3.check.md` |
| OPS1_4 | Use a CI/CD build process | `OPS1_4.check.md` |
| OPS1_5 | Multi-stage builds | `OPS1_5.check.md` |
| OPS1_6 | Implement a minimal container image design to achieve your b | `OPS1_6.check.md` |
| OPS1_7 | Using package managers to deploy your containerized applicat | `OPS1_7.check.md` |

### OPS2: How do you know whether your containerized workload is achieving its business goals?

| Check | Title | File |
|-------|-------|------|
| OPS2_1 | Implement health checks to determine container state | `OPS2_1.check.md` |
| OPS2_2 | Have your logs available outside the running container | `OPS2_2.check.md` |

---

## Composite Validation Script

Run all Operational Excellence checks for this lens:

```python
#!/usr/bin/env python3
"""
Container Build Lens - Operational Excellence Pillar Validation
Runs all checks and reports compliance status.
"""
import importlib.util
import os
import sys

def run_all_operationalexcellence_checks():
    checks_dir = os.path.dirname(os.path.abspath(__file__))
    results = {}
    
    check_files = [
        'OPS1_1.check.md',
        'OPS1_2.check.md',
        'OPS1_3.check.md',
        'OPS1_4.check.md',
        'OPS1_5.check.md',
        'OPS1_6.check.md',
        'OPS1_7.check.md',
        'OPS2_1.check.md',
        'OPS2_2.check.md',
    ]
    
    # Summary
    total = 9
    print(f"\n{'='*60}")
    print(f"OPERATIONAL EXCELLENCE PILLAR - Container Build Lens")
    print(f"{'='*60}")
    print(f"  Total checks: {total}")
    print(f"  All checks have inline validation logic in their .check.md files")
    print(f"  Run individual validate_implementation() functions per check")
    
    return results

if __name__ == '__main__':
    run_all_operationalexcellence_checks()
```

---

## Key AWS Services

- Amazon ECS
- Amazon EKS
- Amazon CloudWatch
- Elastic Load Balancing
- AWS Direct Connect
- AWS CodePipeline
