# Container Build Lens - Performance Skill

## Overview

**Pillar:** Performance (performance)  
**Lens:** Container Build Lens  
**Questions Covered:** 6  
**Total Checks:** 9  
**All Validated (Automation-Ready):** ✅ Yes (95%+ service linkable)  
**Generated On:** 2026-06-18

This skill aggregates all Performance checks for the Container Build Lens into a single reference for pillar-level assessment and automation.

---

## Questions Summary

| Question | Title | Checks |
|----------|-------|--------|
| PERF1 | How do you reduce the size of your container image? | 3 |
| PERF2 | How do you reduce the pull time of your container image? | 1 |
| PERF3 | How do you make sure to get consistent results for your targ | 1 |
| PERF4 | How do you make sure to use updated versions for parent imag | 1 |
| PERF5 | How do you make sure you get consistent performance results  | 1 |
| PERF6 | How do you optimize the size of your target image? | 2 |

---

## Checks Index


### PERF1: How do you reduce the size of your container image?

| Check | Title | File |
|-------|-------|------|
| PERF1_1 | Use small parent images | `PERF1_1.check.md` |
| PERF1_2 | Run a single process per container | `PERF1_2.check.md` |
| PERF1_3 | Exclude files with from your build process | `PERF1_3.check.md` |

### PERF2: How do you reduce the pull time of your container image?

| Check | Title | File |
|-------|-------|------|
| PERF2_1 | Use a container registry close to your cluster | `PERF2_1.check.md` |

### PERF3: How do you make sure to get consistent results for your target images?

| Check | Title | File |
|-------|-------|------|
| PERF3_1 | Use a tag other than latest | `PERF3_1.check.md` |

### PERF4: How do you make sure to use updated versions for parent images?

| Check | Title | File |
|-------|-------|------|
| PERF4_1 | Implement a notification mechanism for updated parent images | `PERF4_1.check.md` |

### PERF5: How do you make sure you get consistent performance results over time?

| Check | Title | File |
|-------|-------|------|
| PERF5_1 | Implement an automated performance testing strategy | `PERF5_1.check.md` |

### PERF6: How do you optimize the size of your target image?

| Check | Title | File |
|-------|-------|------|
| PERF6_1 |  Use caching during build | `PERF6_1.check.md` |
| PERF6_2 | Use the CPU architecture with best price to performance rati | `PERF6_2.check.md` |

---

## Composite Validation Script

Run all Performance checks for this lens:

```python
#!/usr/bin/env python3
"""
Container Build Lens - Performance Pillar Validation
Runs all checks and reports compliance status.
"""
import importlib.util
import os
import sys

def run_all_performance_checks():
    checks_dir = os.path.dirname(os.path.abspath(__file__))
    results = {}
    
    check_files = [
        'PERF1_1.check.md',
        'PERF1_2.check.md',
        'PERF1_3.check.md',
        'PERF2_1.check.md',
        'PERF3_1.check.md',
        'PERF4_1.check.md',
        'PERF5_1.check.md',
        'PERF6_1.check.md',
        'PERF6_2.check.md',
    ]
    
    # Summary
    total = 9
    print(f"\n{'='*60}")
    print(f"PERFORMANCE PILLAR - Container Build Lens")
    print(f"{'='*60}")
    print(f"  Total checks: {total}")
    print(f"  All checks have inline validation logic in their .check.md files")
    print(f"  Run individual validate_implementation() functions per check")
    
    return results

if __name__ == '__main__':
    run_all_performance_checks()
```

---

## Key AWS Services

- Amazon EC2
- Amazon ECS
- Amazon CloudWatch
- Amazon ECR
- AWS CodeBuild
- AWS CodePipeline
- AWS Backup
- AWS Auto Scaling
