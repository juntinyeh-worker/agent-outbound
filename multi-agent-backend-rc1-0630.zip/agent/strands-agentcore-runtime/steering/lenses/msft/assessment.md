# Microsoft on AWS Lens - Assessment Skill

## Overview

**Pillar:** Assessment (ASSESS)  
**Lens:** Microsoft on AWS Lens  
**Questions Covered:** 1  
**Total Checks:** 6  
**All Validated (Automation-Ready):** ✅ Yes (95%+ service linkable)  
**Generated On:** 2026-06-18

This skill aggregates all Assessment checks for the Microsoft on AWS Lens into a single reference for pillar-level assessment and automation.

---

## Questions Summary

| Question | Title | Checks |
|----------|-------|--------|
| ASSESS_q1 | Have you assessed your Microsoft workload environment? | 6 |

---

## Checks Index


### ASSESS_q1: Have you assessed your Microsoft workload environment?

| Check | Title | File |
|-------|-------|------|
| ASSESS_q1_choice1 | Run the AWS Optimization and Licensing Assessment (OLA) | `ASSESS_q1_choice1.check.md` |
| ASSESS_q1_choice2 | Centralize in the AWS Migration Hub | `ASSESS_q1_choice2.check.md` |
| ASSESS_q1_choice3 | Use the Application Discovery Service | `ASSESS_q1_choice3.check.md` |
| ASSESS_q1_choice4 | Use the Migration Evaluator | `ASSESS_q1_choice4.check.md` |
| ASSESS_q1_choice5 | Use the Resource Discovery for Azure | `ASSESS_q1_choice5.check.md` |
| ASSESS_q1_choice6 | None of these. | `ASSESS_q1_choice6.check.md` |

---

## Composite Validation Script

Run all Assessment checks for this lens:

```python
#!/usr/bin/env python3
"""
Microsoft on AWS Lens - Assessment Pillar Validation
Runs all checks and reports compliance status.
"""
import importlib.util
import os
import sys

def run_all_assess_checks():
    checks_dir = os.path.dirname(os.path.abspath(__file__))
    results = {}
    
    check_files = [
        'ASSESS_q1_choice1.check.md',
        'ASSESS_q1_choice2.check.md',
        'ASSESS_q1_choice3.check.md',
        'ASSESS_q1_choice4.check.md',
        'ASSESS_q1_choice5.check.md',
        'ASSESS_q1_choice6.check.md',
    ]
    
    # Summary
    total = 6
    print(f"\n{'='*60}")
    print(f"ASSESSMENT PILLAR - Microsoft on AWS Lens")
    print(f"{'='*60}")
    print(f"  Total checks: {total}")
    print(f"  All checks have inline validation logic in their .check.md files")
    print(f"  Run individual validate_implementation() functions per check")
    
    return results

if __name__ == '__main__':
    run_all_assess_checks()
```

---

## Key AWS Services

- Amazon CloudWatch
