# Microsoft on AWS Lens - Sustainability Skill

## Overview

**Pillar:** Sustainability (SUS)  
**Lens:** Microsoft on AWS Lens  
**Questions Covered:** 1  
**Total Checks:** 4  
**All Validated (Automation-Ready):** ✅ Yes (95%+ service linkable)  
**Generated On:** 2026-06-18

This skill aggregates all Sustainability checks for the Microsoft on AWS Lens into a single reference for pillar-level assessment and automation.

---

## Questions Summary

| Question | Title | Checks |
|----------|-------|--------|
| SUS_q1 | How do you design your Microsoft workload to minimize its en | 4 |

---

## Checks Index


### SUS_q1: How do you design your Microsoft workload to minimize its environmental impact?

| Check | Title | File |
|-------|-------|------|
| SUS_q1_choice1 | Align business requirements with sustainable Microsoft archi | `SUS_q1_choice1.check.md` |
| SUS_q1_choice2 | Optimize Microsoft ecosystem for sustainability. | `SUS_q1_choice2.check.md` |
| SUS_q1_choice3 | Monitor Microsoft sustainability performance. | `SUS_q1_choice3.check.md` |
| SUS_q1_choice4 | None of these. | `SUS_q1_choice4.check.md` |

---

## Composite Validation Script

Run all Sustainability checks for this lens:

```python
#!/usr/bin/env python3
"""
Microsoft on AWS Lens - Sustainability Pillar Validation
Runs all checks and reports compliance status.
"""
import importlib.util
import os
import sys

def run_all_sus_checks():
    checks_dir = os.path.dirname(os.path.abspath(__file__))
    results = {}
    
    check_files = [
        'SUS_q1_choice1.check.md',
        'SUS_q1_choice2.check.md',
        'SUS_q1_choice3.check.md',
        'SUS_q1_choice4.check.md',
    ]
    
    # Summary
    total = 4
    print(f"\n{'='*60}")
    print(f"SUSTAINABILITY PILLAR - Microsoft on AWS Lens")
    print(f"{'='*60}")
    print(f"  Total checks: {total}")
    print(f"  All checks have inline validation logic in their .check.md files")
    print(f"  Run individual validate_implementation() functions per check")
    
    return results

if __name__ == '__main__':
    run_all_sus_checks()
```

---

## Key AWS Services

- Amazon EC2
- Amazon CloudWatch
- AWS Organizations
- AWS Cost Explorer
