# Context-Aware Review Flow

**Purpose**: Execute a Well-Architected review tuned to the workload's business context.
**Prerequisite**: A context object from `workload-onboarding` (provided as JSON in the request or conversation history).

---

## DEMO MODE

If DEMO_MODE is active (you will see `[SIMULATED]` prefixes on API responses), **skip all individual API calls** and output the pre-built demo report below. Do NOT call any tools except `get_steering` to load lens files for reference.

Use the demo context:
- Workload: "Hybrid Aurora Production" (api_service)
- Services: Aurora MySQL, ECS, ALB, VPN, Direct Connect, Transit Gateway
- Compliance: SOC2
- Data: Confidential | SLA: 99.95% | Env: Production
- Lenses: aurora-mysql + hybrid-network

### Demo Report

```markdown
# 🏗️ Context-Aware Well-Architected Review

**Workload**: Hybrid Aurora Production (API Service)
**Compliance**: SOC2 | **Data**: Confidential | **SLA**: 99.95% | **Env**: Production
**Lenses Applied**: Aurora MySQL + Hybrid Network
**Severity Profile**: SOC2 Production (encryption=HRI, HA=HRI, audit=HRI)
**Date**: 2026-06-20

---

## Review Configuration

Based on your workload context, I applied the following tuning:

| Parameter | Standard | Your Profile |
|-----------|----------|--------------|
| Encryption at rest | MRI | **HRI** (confidential data + SOC2) |
| Multi-AZ / HA | MRI | **HRI** (99.95% SLA) |
| Audit logging | MRI | **HRI** (SOC2 requirement) |
| Network segmentation | MRI | **HRI** (hybrid connectivity) |
| Key rotation | MRI | MRI (90-day default OK for SOC2) |
| WAF | MRI | **HRI** (public API + confidential data) |
| Backup RPO | Advisory | **MRI** (99.95% = RPO < 4h) |
| Container scanning | Advisory | MRI (ECS in use) |

Checks skipped: serverless, ML/AI, batch processing, Windows/MSFT

---

## Scan Flow — Commands Executed

### Aurora MySQL Lens Checks
```
$ aws rds describe-db-clusters --query 'DBClusters[?Engine==`aurora-mysql`]'
$ aws rds describe-db-instances (PubliclyAccessible, MultiAZ, AutoMinorVersionUpgrade)
$ aws kms describe-key (cluster KMS key — rotation, key policy)
$ aws rds describe-db-cluster-parameters (require_secure_transport, audit logging)
$ aws ec2 describe-security-groups (DB security group — no 0.0.0.0/0)
$ aws backup list-backup-plans (Aurora backup coverage)
```

### Hybrid Network Lens Checks
```
$ aws ec2 describe-vpn-connections (tunnel status, redundancy)
$ aws directconnect describe-connections (connection state, redundancy)
$ aws ec2 describe-transit-gateways (route propagation, attachment count)
$ aws ec2 describe-vpc-peering-connections (cross-VPC isolation)
$ aws ec2 describe-route-tables (BGP propagation, black-hole routes)
$ aws ec2 describe-flow-logs (VPC flow logging for hybrid subnets)
$ aws networkmanager describe-global-networks (if Cloud WAN)
```

### Cross-Cutting Security Checks (Context-Tuned)
```
$ aws guardduty list-detectors → get-findings (network-related)
$ aws cloudtrail describe-trails (multi-region, log validation)
$ aws config describe-compliance-by-config-rule
$ aws iam get-credential-report (MFA, key age)
```

---

## Executive Summary

| Category | Findings | Severity |
|----------|----------|----------|
| Aurora MySQL — Security | 1 HRI, 1 MRI | 🔴 Action needed |
| Aurora MySQL — Reliability | 0 HRI, 1 MRI | 🟡 Review |
| Aurora MySQL — Performance | 0 HRI, 2 MRI | 🟡 Review |
| Hybrid Network — Security | 1 HRI, 2 MRI | 🔴 Action needed |
| Hybrid Network — Reliability | 1 HRI, 1 MRI | 🔴 Action needed |
| Cross-Cutting — IAM/Audit | 1 HRI, 1 MRI | 🔴 Action needed |

**Total**: 4 HRI · 8 MRI · Context compliance gap: **SOC2 82%** (target: 100%)

---

## 🔴 Critical Findings (HRI — Context-Elevated)

### 1. Aurora MySQL: Advanced Audit Logging Disabled
- **Context trigger**: SOC2 requires access audit trails for confidential data
- **Resource**: prod-aurora-mysql cluster
- **Check**: `server_audit_logging` parameter not enabled
- **Impact**: SOC2 CC6.1 control failure — cannot demonstrate access monitoring
- **Remediation**:
  ```
  aws rds modify-db-cluster-parameter-group \
    --db-cluster-parameter-group-name prod-aurora-params \
    --parameters "ParameterName=server_audit_logging,ParameterValue=1,ApplyMethod=immediate"
  ```
- **Severity reasoning**: Standard=MRI, elevated to HRI due to SOC2 + confidential data

### 2. Hybrid Network: Single VPN Tunnel (No Redundancy)
- **Context trigger**: 99.95% SLA requires redundant connectivity
- **Resource**: vpn-0abc1234 — only 1 tunnel UP
- **Check**: VPN connection has 2 tunnels but only 1 is active/configured
- **Impact**: Single point of failure for hybrid connectivity. Tunnel failure = total outage for on-prem traffic
- **Remediation**: Configure customer gateway for both tunnel endpoints. Verify BGP on both.
- **Severity reasoning**: Standard=MRI, elevated to HRI due to 99.95% SLA

### 3. Hybrid Network: No VPC Flow Logs on Transit Gateway Subnets
- **Context trigger**: SOC2 audit requirement + hybrid network = must log all cross-boundary traffic
- **Resource**: Subnets attached to tgw-0def5678
- **Check**: No flow logs on transit gateway attachment subnets
- **Impact**: Cannot audit traffic flowing between on-prem and cloud (SOC2 CC6.6, CC7.2)
- **Remediation**:
  ```
  aws ec2 create-flow-log --resource-type Subnet --resource-id subnet-tgw-attach \
    --traffic-type ALL --log-destination-type cloud-watch-logs \
    --log-group-name /vpc/tgw-flow-logs
  ```

### 4. IAM: Service Account Without MFA (ci-deploy)
- **Context trigger**: SOC2 CC6.1 — all credentials must have MFA or compensating controls
- **Resource**: IAM user `ci-deploy`
- **Check**: mfa_active=false, access key age=476 days
- **Remediation**: Migrate to IAM role for CI/CD (no long-lived credentials) or enforce MFA on programmatic access via SCP

---

## 🟡 Medium Findings (MRI)

### 5. Aurora: Performance Insights Retention < 7 Days
- Default free tier retention. Insufficient for SOC2 performance audit trail.
- **Remediation**: Enable paid retention (7+ days)

### 6. Aurora: No Read Replica for Read-Heavy Queries
- Single writer instance handles all traffic. Risk for 99.95% under load.
- **Remediation**: Add reader instance in second AZ

### 7. Hybrid: Direct Connect Has No LAG (Single Connection)
- No link aggregation. Single fiber cut = connectivity loss.
- **Remediation**: Add second DX connection or configure VPN as backup

### 8. Hybrid: BGP Route Propagation Not Monitored
- No CloudWatch alarm on BGP session state changes.
- **Remediation**: Create alarm on `TunnelState` metric

### 9. Aurora: KMS Key Policy Not Reviewed
- Key mrk-1234abcd has rotation enabled ✅ but key policy grants broad access
- **Remediation**: Audit key policy for least-privilege

### 10. Network: No WAF on Public ALB
- Public ALB without WAF layer (elevated from Advisory due to confidential data)
- **Remediation**: Create WAF WebACL with AWS managed rules (SQLi, XSS, IP reputation)

### 11. Hybrid: No Network Firewall Between VPCs
- Transit gateway routes all traffic without inspection
- **Remediation**: Consider AWS Network Firewall for east-west inspection

### 12. Audit: CloudTrail Log File Validation
- Log validation enabled ✅ but no alarm on validation failures
- **Remediation**: Create metric filter + alarm for log tampering detection

---

## Remediation Roadmap (Priority Order)

| # | Finding | Effort | Impact | Timeline |
|---|---------|--------|--------|----------|
| 1 | Enable Aurora audit logging | Low (parameter change) | SOC2 blocker | Immediate |
| 2 | Fix VPN dual-tunnel | Medium (network config) | Availability risk | This week |
| 3 | Enable TGW subnet flow logs | Low (API call) | SOC2 audit gap | Immediate |
| 4 | Migrate ci-deploy to IAM role | Medium (CI/CD change) | Credential risk | This sprint |
| 5 | Add WAF to ALB | Medium (WAF setup) | Data protection | This sprint |
| 6 | Add DX redundancy/VPN backup | High (infrastructure) | Availability | This quarter |

---

*Review generated with context-aware severity tuning. Findings marked "context trigger" would be lower severity for non-SOC2 or non-production workloads.*
```

**END OF DEMO REPORT** — Output the above directly. Do not call any tools.

---

## Live Mode Execution

When NOT in demo mode, follow this procedure:

### Step 1: Parse Context

Read the context JSON from the user's message. Extract:
- `review_config.lenses` → which lens steering files to load
- `compliance` + `data_classification` + `availability` → severity tuning rules
- `workload.services` → focus API calls on these services
- `environment` → skip/downgrade rules

### Step 2: Load Relevant Lenses

For each lens in `review_config.lenses`:
```
get_steering("lenses/{lens-name}/security")
get_steering("lenses/{lens-name}/reliability")
get_steering("lenses/{lens-name}/performance-efficiency")
```

Only load pillars relevant to the context:
- Always load: security
- If availability ≥ 99.95%: load reliability
- If budget != cost_optimize: load performance
- If budget == cost_optimize: load cost-optimization

### Step 3: Execute Checks with Context Tuning

For each check in the loaded lenses:
1. Determine if the check is relevant (skip if service not in workload.services)
2. Execute the check via `call_boto3` or `call_aws`
3. Apply severity based on context rules:
   - If compliance requires it → HRI
   - If SLA requires it → HRI
   - If environment=dev → downgrade to Advisory
   - Otherwise → use lens default

### Step 4: Generate Report

Output the report in the format shown above, including:
- Context summary header
- Severity tuning table (showing what was adjusted and why)
- Commands executed
- Findings grouped by severity with "context trigger" annotations
- Remediation roadmap ordered by impact

### Step 5: Recommendations

After findings, add workload-specific recommendations:
- For hybrid: network redundancy, monitoring, segmentation
- For Aurora: performance tuning, backup strategy, encryption
- For compliance: specific control mappings (PCI req#, SOC2 CC#)
