# Workload Onboarding — Context Capture

**Purpose**: Gather business context to customize subsequent Well-Architected reviews.
**Output**: A structured JSON context object that drives lens selection, severity tuning, and custom check generation.

---

## Instructions

When invoked, ask the user the following questions one at a time (or accept a pre-filled JSON profile). After all answers are collected, output the context object as a fenced JSON block and confirm the review configuration.

If the user provides a natural language description (e.g., "PCI production Aurora MySQL app"), infer answers from the description and confirm with the user.

---

## Questions

### Q1: Workload Name & Type
> What is the workload name and type?

Options: `web_app` | `api_service` | `data_pipeline` | `ml_ai` | `saas_multi_tenant` | `batch_processing` | `hybrid_network`

### Q2: Compliance Requirements
> What compliance frameworks apply?

Options (multi-select): `pci-dss` | `hipaa` | `soc2` | `iso27001` | `fedramp` | `none`

### Q3: Data Classification
> What is the highest data classification level?

Options: `public` | `internal` | `confidential` | `restricted`

### Q4: Availability SLA
> What is your availability requirement?

Options: `best-effort` | `99.9` | `99.95` | `99.99`

### Q5: Environment
> What environment is this?

Options: `development` | `staging` | `production`

### Q6: Primary AWS Services
> What AWS services does this workload use?

Free text or list. Examples: ECS, Aurora MySQL, ElastiCache, ALB, S3, Lambda, VPN, Direct Connect

### Q7: Team & Maturity
> How would you describe your operations team?

Options: `solo_dev` | `small_team` | `dedicated_sre` | `enterprise_ops`

### Q8: Budget Sensitivity
> What is your cost vs. reliability preference?

Options: `cost_optimize` | `balanced` | `performance_first`

---

## Output Format

After collecting answers, output:

```json
{
  "workload": {
    "name": "<workload name>",
    "type": "<workload_type>",
    "services": ["<service1>", "<service2>", ...]
  },
  "compliance": ["<framework1>", ...],
  "data_classification": "<level>",
  "availability": "<sla>",
  "environment": "<env>",
  "team": "<maturity>",
  "budget": "<preference>",
  "review_config": {
    "lenses": ["<auto-selected lenses>"],
    "severity_profile": "<derived profile name>",
    "skip_checks": ["<categories to skip>"]
  }
}
```

## Lens Auto-Selection Rules

| Workload Services | → Lens |
|---|---|
| aurora-mysql, rds (aurora) | `lenses/aurora-mysql` |
| ecs, ecr, docker, container | `lenses/container-build` |
| vpn, direct-connect, transit-gateway, hybrid | `lenses/hybrid-network` |
| windows, .net, sql-server, ad | `lenses/msft` |
| (always) | `wa-security-workflow` (security pillar) |

## Severity Profile Rules

| Context | Severity Adjustments |
|---|---|
| compliance includes `pci-dss` | Encryption=HRI, WAF=HRI, KeyRotation≤90d=HRI, Segmentation=HRI, Logging1yr=HRI |
| compliance includes `hipaa` | Encryption=HRI, AuditLog=HRI, AccessControl=HRI |
| availability = `99.99` | MultiAZ=HRI, Backup=HRI, DR=HRI, AutoScale=HRI |
| environment = `development` | Downgrade all MRI→Advisory, skip HA checks |
| environment = `production` | Upgrade encryption/MFA from MRI→HRI |
| data_classification = `restricted` | Encryption=HRI, AccessControl=HRI, DLP=HRI |

## Confirmation Message

After generating the context, respond with:

```
✅ Workload context captured:
- **Name**: {name} ({type})
- **Compliance**: {compliance list}
- **Data**: {classification} | **SLA**: {availability} | **Env**: {environment}
- **Lenses selected**: {lens list}
- **Severity profile**: {profile description}

Ready to run the context-aware review. Say "proceed" or adjust any parameters.
```
