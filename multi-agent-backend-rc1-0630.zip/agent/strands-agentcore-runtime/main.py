"""Strands Agent as AgentCore Runtime - synchronous execution."""
import os
import logging
from aws_api_agent import create_supervisor_agent
from agent_factory import create_agent_for_role
from bedrock_agentcore.runtime import BedrockAgentCoreApp

LOG_GROUP = os.getenv("CW_LOG_GROUP", "/agentcore/sandbox-plx-msp-checker-agent")
REGION = os.getenv("AWS_REGION", "us-west-2")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(name)s %(levelname)s %(message)s',
)
logger = logging.getLogger(__name__)

_cw_initialized = False

def _init_cw_logging():
    """Lazily attach CloudWatch handler after container has credentials."""
    global _cw_initialized
    if _cw_initialized:
        return
    _cw_initialized = True
    try:
        import watchtower, boto3
        cw_handler = watchtower.CloudWatchLogHandler(
            log_group_name=LOG_GROUP,
            log_stream_name=f"agent-{os.getpid()}",
            boto3_client=boto3.client("logs", region_name=REGION),
            create_log_group=True,
        )
        logging.getLogger().addHandler(cw_handler)
        logger.info("[CW] CloudWatch logging initialized")
    except Exception as e:
        logger.warning(f"[CW] CloudWatch logging failed: {e}")

app = BedrockAgentCoreApp()


@app.entrypoint
def main(payload):
    """Handle incoming requests - synchronous agent execution."""
    _init_cw_logging()
    user_input = payload.get("input", payload.get("prompt", ""))
    logger.info(f"[ENTRYPOINT] input={user_input[:100]}")

    if not user_input:
        return {"status": "error", "response": "No input provided."}

    try:
        role_id = payload.get("role_id", "")
        input_context = payload.get("input_context", None)

        if role_id:
            agent = create_agent_for_role(role_id)
        else:
            agent = create_supervisor_agent()

        # Build the full prompt: inject input_context as preceding context
        full_input = ""
        if input_context:
            from_role = input_context.get("from_role", "previous role")
            artifact = input_context.get("artifact", "")
            summary = input_context.get("summary", "")
            full_input += f"## Input from {from_role}\n"
            if summary:
                full_input += f"**Summary:** {summary}\n\n"
            if artifact:
                full_input += f"### Handoff Artifact\n{artifact}\n\n"
            full_input += "---\n\n"

        full_input += f"## Current Task\n{user_input}"

        logger.info(f"[AGENT] Invoking (role={role_id or 'supervisor'}, has_context={bool(input_context)})...")
        response = agent(full_input)
        result_text = response.message['content'][0]['text']
        logger.info(f"[AGENT] DONE, response length={len(result_text)}")

        # Build response with output_artifact for handoff
        resp = {"status": "complete", "response": result_text}

        # Extract output_artifact if the agent produced structured output
        # The agent's response becomes the artifact for the next role
        resp["output_artifact"] = {
            "role": role_id,
            "content": result_text,
            "summary": result_text[:200].split('\n')[0]  # First line as summary
        }

        return resp
    except Exception as e:
        logger.error(f"[AGENT] FAILED: {e}")
        return {"status": "error", "response": f"Error: {e}"}


if __name__ == "__main__":
    logger.info("Starting Strands AgentCore Runtime")
    app.run()
