#!/bin/bash
# Sync role definitions from local to S3 role store bucket
set -euo pipefail
BUCKET="${ROLE_STORE_BUCKET:?Set ROLE_STORE_BUCKET env var}"
REGION="${AWS_REGION:-us-west-2}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
aws s3 sync "$SCRIPT_DIR/" "s3://$BUCKET/" --region "$REGION" --delete --exclude "sync-to-s3.sh"
echo "Synced roles to s3://$BUCKET/"
